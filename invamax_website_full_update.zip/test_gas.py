import urllib.request
import json

url = 'https://script.google.com/macros/s/AKfycbwINtrEt8nfP0lzCeTKAbmCgUzsgGs_EkGdmEKjQQfxKubCoIAnhivJK0mNnuHFd4Ds/exec'
data = {
    'formType': 'contact',
    'hoTen': 'Test Bot',
    'chucDanh': 'Tester',
    'soDienThoai': '123456',
    'email': 'test@example.com',
    'tenNhaMay': 'Test Factory',
    'diaChi': 'Test Address',
    'linhVuc': 'Test',
    'quyMo': 'Test',
    'noiDung': 'Test Content'
}

req = urllib.request.Request(url, method='POST')
req.add_header('Content-Type', 'text/plain;charset=utf-8')
jsondata = json.dumps(data)
jsondataasbytes = jsondata.encode('utf-8')
req.add_header('Content-Length', len(jsondataasbytes))

try:
    response = urllib.request.urlopen(req, jsondataasbytes)
    print("Status:", response.status)
    print("Body:", response.read().decode('utf-8'))
except urllib.error.HTTPError as e:
    print("HTTP Error:", e.code)
    print("Body:", e.read().decode('utf-8'))
except Exception as e:
    print("Error:", e)
