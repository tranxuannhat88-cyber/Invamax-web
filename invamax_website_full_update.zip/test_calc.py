import json
import re

with open('kham-benh-online/assets/js/questions_data.js', 'r', encoding='utf-8') as f:
    js_content = f.read()

# We don't really need to parse the whole object, just extract `nhom` and `id` and `trongSo`
# The JS structure:
# { id: "B01", type: "radio", question: "...", options: [...], trongSo: 3, nhom: "Sản xuất thừa" },

def get_questions(js_content, part):
    pattern = r'part' + part + r'\s*:\s*\[(.*?)\]'
    match = re.search(pattern, js_content, re.DOTALL)
    if not match: return []
    arr_str = match.group(1)
    
    questions = []
    # Find all objects {}
    obj_matches = re.findall(r'\{(.*?)\}', arr_str, re.DOTALL)
    for obj_str in obj_matches:
        q = {}
        # match id
        id_m = re.search(r'id\s*:\s*["\'](.*?)["\']', obj_str)
        if id_m: q['id'] = id_m.group(1)
        
        # match trongSo
        ts_m = re.search(r'trongSo\s*:\s*(\d+)', obj_str)
        if ts_m: q['trongSo'] = int(ts_m.group(1))
        
        # match nhom
        nhom_m = re.search(r'nhom\s*:\s*["\'](.*?)["\']', obj_str)
        if nhom_m: q['nhom'] = nhom_m.group(1)
        
        questions.append(q)
    return questions

partB = get_questions(js_content, 'B')
partC = get_questions(js_content, 'C')
partD = get_questions(js_content, 'D')

rawAnswers = {"A01":"Nhất","A02":"Hải Phòng","A03":"Cơ khí / kim loại","A04":"Tủ","A05":"2","A06":"34","A07":"5","A08":"9","A09":"1 ca","A10":"Appsheet","B01":"2","B02":"2","B03":"2","B04":"3","B05":"3","B06":"3","B07":"2","B08":"4","B09":"2","B10":"1","B11":"1","B12":"1","B13":"1","B14":"3","B15":"3","B16":"3","C01":"2","C02":"2","C03":"3","C04":"3","C05":"4","C06":"3","C07":"2","C08":"2","C09":"2","C10":"2","C11":"1","C12":"1","C13":"3","C14":"3","C15":"3","C16":"2","C17":"3","C18":"2","C19":"2","C20":"2","C21":"2","C22":"3","C23":"3","C24":"3","D01":"1","D02":"2","D03":"2","D04":"3","D05":"3","D06":"2","D07":"2","D08":"2","D09":"2","D10":"2","D11":"2","D12":"3","D13":"2","D14":"2","D15":"3","D16":"2","D17":"1","D18":"2","D19":"3","D20":"3","D21":"2","D22":"2","D23":"2","D24":"2","D25":"3","D26":"3","D27":"3","D28":"3","D29":"2","D30":"2","D31":"2","D32":"2","D33":"1","E01":"Tăng doanh thu hoặc mở rộng thị trường","E02":"1","E03":"Thị trường và đơn hàng","E04":"2","E05":"Tiêu chuẩn và hướng dẫn công việc","E06":"1","E07":"2","F01":"Trần Xuân Nhất","F02":"Giám đốc","F03":"","F04":"0988911869","F05":"Đồng ý"}

def getGroupScore(questions):
    score = 0
    weight = 0
    for q in questions:
        val = rawAnswers.get(q.get('id', ''))
        if val:
            score += int(val) * q.get('trongSo', 1)
            weight += q.get('trongSo', 1)
    return score / weight if weight > 0 else 0

wScore = getGroupScore(partB)
sScore = getGroupScore(partC)
mScore = getGroupScore(partD)

warningScore = ((wScore * 0.4 + sScore * 0.4 + mScore * 0.2) / 4) * 100
warningScore = round(warningScore)
print("warningScore:", warningScore)

wasteScores = []
wasteModules = list(set([q.get('nhom') for q in partB if q.get('nhom')]))
for module in wasteModules:
    qs = [q for q in partB if q.get('nhom') == module]
    wasteScores.append({
        'module': module,
        'score': round((getGroupScore(qs) / 4) * 100)
    })
print("wasteScores:")
for w in wasteScores:
    print(w)

fosScores = []
fosModules = list(set([q.get('nhom') for q in partD if q.get('nhom')]))
for module in fosModules:
    qs = [q for q in partD if q.get('nhom') == module]
    fosScores.append({
        'module': module,
        'score': round((getGroupScore(qs) / 4) * 100)
    })
print("fosScores:")
for f in fosScores:
    print(f)
