import io

file_path = 'san-pham.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# For Card "Linh kiện & Vật tư kết cấu"
target_text_1 = "<p>Cung cấp hệ linh kiện lắp ráp nhanh (khớp nối, bánh xe, phụ kiện nhôm định hình) phục vụ cho các dự án Kaizen tại nhà máy.</p>\n                </div>"
replacement_1 = """<p class="mb-4">Cung cấp hệ linh kiện lắp ráp nhanh (khớp nối, bánh xe, phụ kiện nhôm định hình) phục vụ cho các dự án Kaizen tại nhà máy.</p>
                    <img src="assets/images/linh_kien_vat_tu.jpg" alt="Linh kiện vật tư" style="width: 100%; border-radius: 8px; border: 1px solid var(--border-color); margin-top: auto; aspect-ratio: 4/3; object-fit: cover;">
                </div>"""

html = html.replace(target_text_1, replacement_1)

# For Card "Thiết bị, dụng cụ sản xuất"
target_text_2 = "<p>Thiết bị tự động, bán tự động. Đồ gá, dưỡng, dụng cụ hỗ trợ sản xuất được chế tạo bởi hệ sinh thái đối tác cơ khí chính xác.</p>\n                </div>"
replacement_2 = """<p class="mb-4">Thiết bị tự động, bán tự động. Đồ gá, dưỡng, dụng cụ hỗ trợ sản xuất được chế tạo bởi hệ sinh thái đối tác cơ khí chính xác.</p>
                    <img src="assets/images/thiet_bi_san_xuat.jpg" alt="Thiết bị sản xuất" style="width: 100%; border-radius: 8px; border: 1px solid var(--border-color); margin-top: auto; aspect-ratio: 4/3; object-fit: cover;">
                </div>"""

html = html.replace(target_text_2, replacement_2)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Added images to san-pham.html")
