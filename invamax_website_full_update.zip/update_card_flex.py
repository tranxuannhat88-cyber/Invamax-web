import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The inline style to replace
    old_style = 'style="display: flex; align-items: flex-start; gap: 20px; padding: 25px;"'
    new_style = 'style="display: flex; flex-direction: row; align-items: flex-start; gap: 20px; padding: 25px;"'
    
    if old_style in html:
        html = html.replace(old_style, new_style)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old inline style in index.html")
except Exception as e:
    print("Error HTML:", e)
