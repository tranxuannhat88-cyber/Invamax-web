import io
import os
import re

dich_vu_html = "dich-vu.html"
template_file = "kham-benh-truc-tiep/gioi-thieu.html"

pages = [
    {
        "id": "fos-standard",
        "title": "NỀN FOS Standard 30 ngày",
        "desc": "Thiết lập các tiêu chuẩn cơ bản: 5S, Quản lý trực quan, chuẩn hóa thao tác và đo lường KPIs cơ bản cho xưởng sản xuất."
    },
    {
        "id": "fos-premium",
        "title": "NỀN FOS Premium 60 ngày",
        "desc": "Chương trình toàn diện: Tối ưu flow, cân bằng chuyền, thiết lập Daily Management System và đào tạo đội ngũ quản lý cấp trung."
    },
    {
        "id": "dong-hanh-quan-tri",
        "title": "Đồng hành quản trị bán thời gian",
        "desc": "Dịch vụ cố vấn định kỳ, hỗ trợ Ban Giám Đốc kiểm soát quá trình cải tiến liên tục mà không cần nhân sự cấp cao full-time."
    },
    {
        "id": "appsheet",
        "title": "Appsheet và hệ sinh thái Google",
        "desc": "Số hóa nhanh chóng các quy trình, biểu mẫu thủ công bằng hệ sinh thái Google (Appsheet, Looker Studio, Google Workspace, Gemini, NotebookLM)."
    },
    {
        "id": "one-paper",
        "title": "One Paper & EIOS",
        "desc": "Số hóa văn bản, tài liệu, quy trình và quản lý bằng EIOS."
    },
    {
        "id": "phan-mem-ai",
        "title": "Phần mềm / AI khác",
        "desc": "Ứng dụng các phần mềm, nền tảng AI khác theo bài toán cụ thể của từng nhà máy."
    }
]

# Read template
with io.open(template_file, 'r', encoding='utf-8') as f:
    template_html = f.read()

# Read dich-vu.html
with io.open(dich_vu_html, 'r', encoding='utf-8') as f:
    dv_html = f.read()

for page in pages:
    target_dir = page["id"]
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
        
    # Create the page
    target_file = os.path.join(target_dir, "gioi-thieu.html")
    
    html = template_html
    # Replace titles
    html = html.replace('Giới thiệu Chương trình Khám bệnh trực tiếp - INVAMAX', f'Chi tiết - {page["title"]} - INVAMAX')
    html = html.replace('Khám Bệnh Trực Tiếp Tại Nhà Máy', page["title"])
    
    # Replace description hero text
    old_hero_p = 'Chuyên gia INVAMAX trực tiếp xuống hiện trường khảo sát toàn diện, phỏng vấn đội ngũ và lập báo cáo lộ trình cải tiến chi tiết, giải quyết các "điểm nghẽn" thực tế.'
    html = html.replace(old_hero_p, page["desc"])
    
    # Save file
    with io.open(target_file, 'w', encoding='utf-8') as f:
        f.write(html)
        
    print(f"Created {target_file}")
    
    # Update dich-vu.html links
    # We find the block starting with the title and replacing the first href="kham-benh-truc-tiep/gioi-thieu.html" after it.
    title_pattern = re.escape(page["title"])
    
    parts = re.split(rf'(<h3[^>]*>.*?{title_pattern}.*?<\/h3>)', dv_html, maxsplit=1)
    if len(parts) == 3:
        before = parts[0]
        h3 = parts[1]
        after = parts[2]
        
        wrong_link = 'kham-benh-truc-tiep/gioi-thieu.html'
        right_link = f'{page["id"]}/gioi-thieu.html'
        after = after.replace(wrong_link, right_link, 1)
        
        dv_html = before + h3 + after
        print(f"Updated link for {page['id']} in dich-vu.html")
    else:
        print(f"Could not find title {page['id']} in dich-vu.html")

# Save dich-vu.html
with io.open(dich_vu_html, 'w', encoding='utf-8') as f:
    f.write(dv_html)
print("Saved dich-vu.html")
