import io
import re

# Read kien-thuc.html to extract the articles
with io.open('kien-thuc.html', 'r', encoding='utf-8') as f:
    kien_thuc = f.read()

# Extract the articles container (class="grid-3")
match = re.search(r'<div class="grid-3">(.*?)</div>\s*</section>', kien_thuc, re.DOTALL)
if match:
    articles_html = match.group(1).strip()
else:
    print("Could not extract articles")
    exit(1)

# Read index.html
with io.open('index.html', 'r', encoding='utf-8') as f:
    index_html = f.read()

# Prepare the new section
new_section = f"""
    <!-- Kiến thức & Phân tích -->
    <section class="section" style="background: var(--bg-dark); border-top: 1px solid var(--border-color);">
        <div class="container">
            <div class="section-header" style="text-align: center; margin-bottom: 40px;">
                <h2>Kiến thức & Phân tích nổi bật</h2>
                <p class="text-muted">Cập nhật những xu hướng và kinh nghiệm thực tiễn về quản trị sản xuất</p>
            </div>
            
            <div class="grid-3">
                {articles_html}
            </div>
            
            <div style="text-align: center; margin-top: 40px;">
                <a href="kien-thuc.html" class="btn btn-outline">Xem tất cả bài viết</a>
            </div>
        </div>
    </section>

    <!-- Lời mời hành động (CTA) -->
"""

# Inject the new section before the CTA
if "<!-- Kiến thức & Phân tích -->" not in index_html:
    index_html = index_html.replace('<!-- Lời mời hành động (CTA) -->', new_section.strip() + '\n\n    <!-- Lời mời hành động (CTA) -->')
    
    with io.open('index.html', 'w', encoding='utf-8') as f:
        f.write(index_html)
    print("Injected latest articles into index.html")
else:
    print("Section already exists")
