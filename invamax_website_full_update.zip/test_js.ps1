$sc = New-Object -ComObject MSScriptControl.ScriptControl
$sc.Language = "JScript"
$js = Get-Content "kham-benh-online/assets/js/admin.js" -Raw
try {
    $sc.Eval($js)
    Write-Output "OK"
} catch {
    Write-Output "ERROR: $($_.Exception.Message)"
}
