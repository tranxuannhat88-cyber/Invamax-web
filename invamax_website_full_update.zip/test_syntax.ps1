$ie = New-Object -COMObject InternetExplorer.Application
$ie.Navigate("file:///C:/Users/MAY TINH 2K/Desktop/invamax-website/test_syntax.html")
while ($ie.Busy -or $ie.ReadyState -ne 4) { Start-Sleep -Milliseconds 100 }
Start-Sleep -Seconds 1
$doc = $ie.Document
$el = $doc.getElementById("error_log")
if ($el) { Write-Output $el.innerText } else { Write-Output "NO SYNTAX ERROR" }
$ie.Quit()
