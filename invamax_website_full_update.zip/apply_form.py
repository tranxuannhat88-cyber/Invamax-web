import io
import re

index_html = r"index.html"
style_css = r"assets\css\style.css"
main_js = r"assets\js\main.js"

# 1. Update style.css
try:
    with io.open(style_css, 'r', encoding='utf-8') as f:
        css = f.read()

    # Update font size for hero-text h1
    css = css.replace('font-size: 3.5rem;', 'font-size: 2.8rem; line-height: 1.25;')

    # Add Modal CSS
    modal_css = '''
/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(4px);
    z-index: 1000;
    display: none;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}
.modal-overlay.active {
    display: flex;
    opacity: 1;
}
.modal-content {
    background: white;
    width: 90%;
    max-width: 600px;
    border-radius: 12px;
    padding: 30px;
    position: relative;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    transform: translateY(20px);
    transition: transform 0.3s ease;
    max-height: 90vh;
    overflow-y: auto;
}
.modal-overlay.active .modal-content {
    transform: translateY(0);
}
.modal-close {
    position: absolute;
    top: 15px; right: 15px;
    background: none; border: none;
    font-size: 1.5rem; color: #64748b;
    cursor: pointer;
}
.modal-close:hover { color: #0f172a; }
.form-group { margin-bottom: 15px; }
.form-group label {
    display: block; font-weight: 600; margin-bottom: 5px; color: #334155; font-size: 0.9rem;
}
.form-group input, .form-group textarea, .form-group select {
    width: 100%; padding: 10px 12px;
    border: 1px solid #cbd5e1; border-radius: 6px;
    font-size: 1rem; font-family: inherit;
    transition: border-color 0.2s;
}
.form-group input:focus, .form-group textarea:focus, .form-group select:focus {
    outline: none; border-color: var(--primary);
}
.form-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 15px;
}
@media (max-width: 600px) {
    .form-grid { grid-template-columns: 1fr; gap: 0; }
}
'''
    if ".modal-overlay" not in css:
        with io.open(style_css, 'a', encoding='utf-8') as f:
            f.write("\n" + modal_css)
        print("Updated style.css")
except Exception as e:
    print("Error CSS:", e)

# 2. Update index.html
try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # Fix H1 text
    old_h1 = '<h1>INVAMAX<br>Thiết kế & Chuyển đổi<br>Mô hình vận hành nhà máy</h1>'
    new_h1 = '<h1>INVAMAX<br>Thiết kế & Chuyển đổi Mô hình vận hành nhà máy</h1>'
    html = html.replace(old_h1, new_h1)

    # Fix Button 1
    old_btn = '<a href="dich-vu.html" class="btn btn-primary">Đánh giá mô hình vận hành <i data-lucide="arrow-right"></i></a>'
    new_btn = '<button onclick="openContactModal()" class="btn btn-outline" style="font-size: 0.95rem;">Liên hệ để đánh giá nhà máy của bạn <i data-lucide="arrow-right"></i></button>'
    html = html.replace(old_btn, new_btn)

    # Fix CTA bottom button as well to open modal
    old_cta_btn = '<a href="dich-vu.html" class="btn" style="background: white; color: var(--primary); padding: 15px 30px; font-size: 1.1rem; font-weight: bold;">Đăng ký khảo sát mô hình vận hành</a>'
    new_cta_btn = '<button onclick="openContactModal()" class="btn" style="background: white; color: var(--primary); padding: 15px 30px; font-size: 1.1rem; font-weight: bold; border:none;">Liên hệ để đánh giá nhà máy của bạn</button>'
    html = html.replace(old_cta_btn, new_cta_btn)

    # Add Modal HTML just before </body>
    modal_html = '''
    <!-- Contact Modal -->
    <div id="contactModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close" onclick="closeContactModal()"><i data-lucide="x"></i></button>
            <h2 style="font-size: 1.5rem; color: var(--primary); margin-bottom: 5px;">Đăng ký Đánh giá Nhà máy</h2>
            <p style="color: #64748b; margin-bottom: 20px; font-size: 0.95rem;">Vui lòng để lại thông tin, chuyên gia INVAMAX sẽ liên hệ lại với bạn trong 24h.</p>
            
            <form id="leadForm" onsubmit="submitForm(event)">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Họ và tên *</label>
                        <input type="text" name="hoTen" required placeholder="Nguyễn Văn A">
                    </div>
                    <div class="form-group">
                        <label>Chức danh *</label>
                        <input type="text" name="chucDanh" required placeholder="Giám đốc / Trưởng phòng">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Số điện thoại *</label>
                        <input type="tel" name="soDienThoai" required placeholder="0988...">
                    </div>
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" required placeholder="email@congty.com">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Tên nhà máy / Công ty *</label>
                    <input type="text" name="tenNhaMay" required placeholder="Công ty TNHH XYZ">
                </div>
                
                <div class="form-group">
                    <label>Địa chỉ nhà máy</label>
                    <input type="text" name="diaChi" placeholder="KCN abc, Tỉnh xyz...">
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Lĩnh vực sản xuất</label>
                        <input type="text" name="linhVuc" placeholder="Cơ khí, điện tử, may mặc...">
                    </div>
                    <div class="form-group">
                        <label>Quy mô nhân sự</label>
                        <select name="quyMo">
                            <option value="Dưới 50 người">Dưới 50 người</option>
                            <option value="50 - 200 người">50 - 200 người</option>
                            <option value="200 - 500 người">200 - 500 người</option>
                            <option value="Trên 500 người">Trên 500 người</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Nội dung cần tư vấn *</label>
                    <textarea name="noiDung" rows="3" required placeholder="Mô tả sơ bộ về định hướng, vấn đề hiện tại của nhà máy..."></textarea>
                </div>
                
                <button type="submit" id="btnSubmitForm" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                    <i data-lucide="send"></i> Gửi Đề Nghị
                </button>
            </form>
            
            <div id="formSuccess" style="display: none; text-align: center; padding: 30px 0;">
                <i data-lucide="check-circle" style="color: #22c55e; width: 64px; height: 64px; margin-bottom: 15px; margin: 0 auto;"></i>
                <h3 style="color: #16a34a; font-size: 1.3rem; margin-top: 15px;">Gửi thành công!</h3>
                <p style="color: #475569; margin-top: 10px;">Cảm ơn bạn. Chuyên gia INVAMAX sẽ sớm liên hệ lại.</p>
                <button type="button" class="btn btn-outline" style="margin-top: 20px;" onclick="closeContactModal()">Đóng cửa sổ</button>
            </div>
        </div>
    </div>
'''
    if "contactModal" not in html:
        html = html.replace('</body>', modal_html + '\n</body>')
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
except Exception as e:
    print("Error HTML:", e)

# 3. Update main.js
try:
    with io.open(main_js, 'a', encoding='utf-8') as f:
        js_code = '''
// Modal Functions
function openContactModal() {
    document.getElementById('contactModal').classList.add('active');
}
function closeContactModal() {
    document.getElementById('contactModal').classList.remove('active');
    document.getElementById('leadForm').style.display = 'block';
    document.getElementById('formSuccess').style.display = 'none';
    document.getElementById('leadForm').reset();
}

// Thay URL Web App của Google Apps Script vào đây
const GOOGLE_SCRIPT_URL = "YOUR_WEB_APP_URL_HERE";

async function submitForm(e) {
    e.preventDefault();
    if(GOOGLE_SCRIPT_URL === "YOUR_WEB_APP_URL_HERE") {
        alert("Tính năng đang được thiết lập (Thiếu URL Webhook).");
        return;
    }
    
    const form = document.getElementById('leadForm');
    const btn = document.getElementById('btnSubmitForm');
    const formData = new FormData(form);
    
    let data = {};
    formData.forEach((value, key) => data[key] = value);
    
    btn.innerHTML = 'Đang gửi...';
    btn.disabled = true;
    
    try {
        const response = await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            body: JSON.stringify(data),
            mode: 'no-cors' // Do Google chặn CORS khi gọi từ client, no-cors sẽ bỏ qua bước check CORS (nhưng k đọc được kết quả trả về)
        });
        
        // Vì no-cors, chúng ta giả định là thành công nếu không có lỗi network throw ra
        document.getElementById('leadForm').style.display = 'none';
        document.getElementById('formSuccess').style.display = 'block';
    } catch(err) {
        alert("Có lỗi xảy ra khi gửi dữ liệu. Vui lòng thử lại sau.");
        console.error(err);
    } finally {
        btn.innerHTML = '<i data-lucide="send"></i> Gửi Đề Nghị';
        btn.disabled = false;
        lucide.createIcons();
    }
}
'''
        f.write("\n" + js_code)
    print("Updated main.js")
except Exception as e:
    print("Error JS:", e)
