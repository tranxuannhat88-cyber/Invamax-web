import io
import re

file_path = 'index.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Replace the specific headline text
old_headline = '<h1 class="hero-main-title">INVAMAX<br>Thiết kế & Chuyển đổi Mô hình vận hành nhà máy</h1>'
new_headline = '<h1 class="hero-main-title">Thiết kế & Chuyển đổi Mô hình vận hành nhà máy</h1>'

html = html.replace(old_headline, new_headline)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Updated headline in index.html")
