import io
import os

# Base HTML template for both pages
def get_html_template(title, hero_title, hero_desc, target_audience, invamax_tasks, factory_tasks, conclusion):
    html = f"""<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        .intro-hero {{
            padding: 120px 0 60px;
            text-align: center;
            background: linear-gradient(to bottom, #0b1120, var(--bg-dark));
        }}
        .intro-section {{
            padding: 60px 0;
        }}
        .module-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 40px;
        }}
        .module-group {{
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 20px;
        }}
        .module-group h4 {{
            color: var(--primary);
            margin-bottom: 15px;
            font-size: 1.1rem;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding-bottom: 10px;
        }}
        .module-item {{
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 12px;
        }}
        .module-item i {{
            color: var(--text-muted);
            width: 18px;
            height: 18px;
            flex-shrink: 0;
            margin-top: 3px;
        }}
        .module-item span {{
            font-size: 0.95rem;
            color: #cbd5e1;
            line-height: 1.4;
        }}
        .module-item strong {{
            display: block;
            color: white;
            font-size: 1rem;
            margin-bottom: 2px;
        }}
        
        .role-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 40px;
        }}
        .role-card {{
            background: rgba(255, 255, 255, 0.03);
            border-radius: 16px;
            padding: 30px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .role-card h3 {{
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--primary);
            margin-bottom: 24px;
            font-size: 1.3rem;
        }}
        .role-list {{
            list-style: none;
            padding: 0;
            margin: 0;
        }}
        .role-list li {{
            position: relative;
            padding-left: 28px;
            margin-bottom: 16px;
            color: #cbd5e1;
            line-height: 1.6;
        }}
        .role-list li::before {{
            content: '✓';
            position: absolute;
            left: 0;
            top: 0;
            color: var(--primary);
            font-weight: bold;
        }}
        
        .conclusion-box {{
            background: rgba(234, 88, 12, 0.1);
            border-left: 4px solid var(--primary);
            padding: 24px;
            border-radius: 0 12px 12px 0;
            margin-top: 40px;
        }}
        .conclusion-box p {{
            margin: 0;
            font-size: 1.1rem;
            color: white;
            font-weight: 500;
        }}
        
        @media (max-width: 992px) {{
            .module-grid {{ grid-template-columns: 1fr 1fr; }}
            .role-grid {{ grid-template-columns: 1fr; }}
        }}
        @media (max-width: 576px) {{
            .module-grid {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>
    <!-- Navbar (Simplified for this script, we assume header is included or similar to others) -->
    <nav class="navbar">
        <div class="container" style="display: flex; justify-content: space-between; align-items: center;">
            <a href="../index.html" class="logo">INVA<span>MAX</span></a>
            <div class="nav-links">
                <a href="../index.html">Trang chủ</a>
                <a href="../dich-vu.html" class="active">Dịch vụ</a>
                <a href="../san-pham.html">Sản phẩm</a>
                <a href="#" class="btn btn-primary" onclick="openContactModal()" style="margin-left: 1rem;">Liên hệ tư vấn</a>
            </div>
        </div>
    </nav>

    <div class="intro-hero">
        <div class="container">
            <h1 class="hero-title" style="margin-bottom: 20px;">{hero_title}</h1>
            <p class="hero-subtitle" style="max-width: 800px; margin: 0 auto 40px; color: #94a3b8; font-size: 1.1rem; line-height: 1.6;">
                {hero_desc}
            </p>
            <button onclick="openContactModal()" class="btn btn-primary btn-lg">Nhận tư vấn & Báo giá</button>
        </div>
    </div>
    
    <section class="intro-section" style="background: rgba(255,255,255,0.02);">
        <div class="container">
            <h2 class="section-title text-center">Bản Đồ 11 Module Hệ Điều Hành Nhà Máy</h2>
            <p class="section-desc text-center">Gói NỀN FOS bao phủ toàn diện 4 nhóm nền tảng cốt lõi của một nhà máy tinh gọn (Lean Manufacturing).</p>
            
            <div class="module-grid">
                <!-- Group 1 -->
                <div class="module-group">
                    <h4>1. NỀN MÓNG QUẢN TRỊ</h4>
                    <div class="module-item">
                        <i data-lucide="crosshair"></i>
                        <div><strong>Core</strong><span>Chiến lược & cơ chế điều hành</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="users"></i>
                        <div><strong>People</strong><span>Con người & năng lực tổ chức</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="git-merge"></i>
                        <div><strong>Flow</strong><span>Quy trình & dòng chảy</span></div>
                    </div>
                </div>
                <!-- Group 2 -->
                <div class="module-group">
                    <h4>2. VẬN HÀNH SẢN XUẤT</h4>
                    <div class="module-item">
                        <i data-lucide="file-check-2"></i>
                        <div><strong>Standard</strong><span>Công việc tiêu chuẩn</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="bar-chart-2"></i>
                        <div><strong>Capacity</strong><span>Năng lực & cân bằng</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="calendar"></i>
                        <div><strong>Daily</strong><span>Điều hành hằng ngày</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="shield-check"></i>
                        <div><strong>Quality</strong><span>Chất lượng tại nguồn</span></div>
                    </div>
                </div>
                <!-- Group 3 -->
                <div class="module-group">
                    <h4>3. TRI THỨC & CÔNG CỤ</h4>
                    <div class="module-item">
                        <i data-lucide="book-open"></i>
                        <div><strong>Knowledge</strong><span>Quản trị tri thức</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="laptop"></i>
                        <div><strong>Digital</strong><span>Công cụ số</span></div>
                    </div>
                </div>
                <!-- Group 4 -->
                <div class="module-group">
                    <h4>4. CẢI TIẾN & DUY TRÌ</h4>
                    <div class="module-item">
                        <i data-lucide="zap"></i>
                        <div><strong>Kaizen</strong><span>Giải quyết vấn đề & cải tiến</span></div>
                    </div>
                    <div class="module-item">
                        <i data-lucide="trending-up"></i>
                        <div><strong>Sustain</strong><span>Duy trì & trưởng thành</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="intro-section">
        <div class="container">
            <h2 class="section-title">Phạm vi triển khai gói {hero_title.split(' - ')[0]}</h2>
            <div style="background: rgba(255,255,255,0.02); padding: 20px; border-radius: 8px; border-left: 3px solid var(--primary); margin-bottom: 30px;">
                <p style="margin: 0; color: #cbd5e1; font-style: italic;"><strong>Phù hợp với:</strong> {target_audience}</p>
            </div>
            
            <div class="role-grid">
                <!-- INVAMAX Role -->
                <div class="role-card">
                    <h3><i data-lucide="briefcase"></i> INVAMAX cung cấp</h3>
                    <ul class="role-list">
                        {invamax_tasks}
                    </ul>
                </div>
                
                <!-- Factory Role -->
                <div class="role-card">
                    <h3><i data-lucide="factory"></i> Nhà máy thực hiện</h3>
                    <ul class="role-list">
                        {factory_tasks}
                    </ul>
                </div>
            </div>
            
            <div class="conclusion-box">
                <p><strong>Tóm lại:</strong> {conclusion}</p>
            </div>
        </div>
    </section>
    
    <!-- Footer (Simplified) -->
    <footer class="footer" style="margin-top: 60px;">
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; 2026 INVAMAX. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="../assets/js/main.js"></script>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>"""
    return html

# -------------------------------------------------------------
# 1. FOS STANDARD
# -------------------------------------------------------------
std_title = "Chi tiết - NỀN FOS Standard 30 ngày - INVAMAX"
std_hero_title = "NỀN FOS Standard 30 ngày"
std_hero_desc = "Thiết lập hệ thống biểu mẫu, quy chuẩn và nền tảng cốt lõi của 11 module quản trị sản xuất. Phù hợp cho đội ngũ muốn tự chủ xây dựng nội dung dưới sự hướng dẫn của chuyên gia."
std_target = "Nhà máy có người nội bộ đủ khả năng triển khai, nhưng còn thiếu phương pháp, bộ form và hệ thống chuẩn."

std_invamax = "".join([f"<li>{item}</li>" for item in [
    "Khảo sát và xác định hiện trạng cơ bản.",
    "Bộ form chuẩn của đủ 11 module.",
    "Hướng dẫn điền và ví dụ tham khảo.",
    "Đào tạo FOS Owner và người phụ trách module.",
    "Lập kế hoạch triển khai theo từng giai đoạn.",
    "Review nội dung do nhà máy hoàn thành.",
    "Một vòng phản hồi chính cho từng đầu ra.",
    "Chuẩn hóa hệ thống mã tài liệu và phiên bản.",
    "Thiết lập kho tài liệu dùng chung.",
    "Cấu hình các biểu mẫu số, Google Sheets/AppSheet và dashboard cơ bản.",
    "Đào tạo sử dụng công cụ.",
    "Kiểm tra trước khi nghiệm thu và ban hành."
]])

std_factory = "".join([f"<li>{item}</li>" for item in [
    "Cử FOS Owner.",
    "Điền nội dung vào các form.",
    "Cung cấp dữ liệu thực tế.",
    "Thử nghiệm tài liệu tại hiện trường.",
    "Chỉnh sửa theo góp ý.",
    "Phê duyệt và ban hành.",
    "Nhập và duy trì dữ liệu hằng ngày.",
    "Đào tạo lại cho nhân viên."
]])
std_conclusion = "INVAMAX cung cấp hệ thống chuẩn, nhà máy chủ động xây nội dung và vận hành."

# -------------------------------------------------------------
# 2. FOS PREMIUM
# -------------------------------------------------------------
prem_title = "Chi tiết - NỀN FOS Premium 60 ngày - INVAMAX"
prem_hero_title = "NỀN FOS Premium 60 ngày"
prem_hero_desc = "Chương trình can thiệp toàn diện và sâu sát. INVAMAX trực tiếp cùng ban lãnh đạo thiết kế hệ thống, tối ưu dòng chảy, và coaching đội ngũ vận hành thực tế tại xưởng."
prem_target = "Nhà máy muốn INVAMAX tham gia sâu hơn vào quá trình thiết kế, tối ưu và đưa hệ thống vào vận hành thực tế."

prem_invamax = "".join([f"<li>{item}</li>" for item in [
    "Toàn bộ nội dung của Standard, đồng thời bổ sung:",
    "Chủ trì workshop cho các module trọng yếu.",
    "Cùng nhà máy xây dựng các quy trình liên phòng ban.",
    "Thiết kế hệ thống mục tiêu và cây KPI.",
    "Phân tích dòng chảy, điểm nghẽn và năng lực.",
    "Thiết kế nhịp điều hành ngày – tuần – tháng.",
    "Coaching xử lý một số vấn đề thực tế.",
    "Review hai đến ba vòng đối với tài liệu quan trọng.",
    "Điều chỉnh bộ form theo đặc thù doanh nghiệp.",
    "Thiết lập workflow, cảnh báo và dashboard nâng cao.",
    "Đào tạo đội ngũ quản lý.",
    "Audit việc áp dụng tại hiện trường.",
    "Hỗ trợ hoàn thiện một số dự án Kaizen trọng điểm.",
    "Đánh giá mức trưởng thành và lập kế hoạch nâng cấp."
]])

prem_factory = "".join([f"<li>{item}</li>" for item in [
    "Cử FOS Owner có đủ quyền điều phối.",
    "Cử Process Owner cho từng nội dung.",
    "Tham gia workshop.",
    "Cung cấp dữ liệu và tri thức chuyên môn.",
    "Thực hiện các giải pháp đã thống nhất.",
    "Chủ trì dần các cuộc họp.",
    "Tự cập nhật tài liệu sau khi được đào tạo.",
    "Tự audit và duy trì hệ thống."
]])
prem_conclusion = "INVAMAX cùng nhà máy thiết kế, tối ưu, chạy thử và xây năng lực tự vận hành."

# Write files
base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

with io.open(os.path.join(base_dir, r'fos-standard\gioi-thieu.html'), 'w', encoding='utf-8') as f:
    f.write(get_html_template(std_title, std_hero_title, std_hero_desc, std_target, std_invamax, std_factory, std_conclusion))

with io.open(os.path.join(base_dir, r'fos-premium\gioi-thieu.html'), 'w', encoding='utf-8') as f:
    f.write(get_html_template(prem_title, prem_hero_title, prem_hero_desc, prem_target, prem_invamax, prem_factory, prem_conclusion))

print("Created FOS Standard and Premium detail pages.")
