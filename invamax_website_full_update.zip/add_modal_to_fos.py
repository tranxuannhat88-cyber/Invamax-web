import io
import os

modal_html = """
    <!-- Contact Modal -->
    <div id="contactModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close" onclick="closeContactModal()" style="font-size: 24px; line-height: 1; font-weight: bold; color: #64748b; background: none; border: none; cursor: pointer;">&times;</button>
            <div class="modal-header">
                <h2 style="font-size: 1.5rem; color: var(--primary); margin-bottom: 5px;">Đăng ký tư vấn</h2>
                <p style="color: #64748b; margin-bottom: 20px; font-size: 0.95rem;">Vui lòng để lại thông tin, chuyên gia của chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.</p>
            </div>
            <form id="contactForm">
                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; color: #334155; font-weight: 500;">Họ và tên *</label>
                    <input type="text" class="form-control" name="name" required placeholder="Nhập họ và tên của bạn" style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px;">
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; color: #334155; font-weight: 500;">Số điện thoại *</label>
                    <input type="tel" class="form-control" name="phone" required placeholder="Số điện thoại liên hệ" style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px;">
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px; padding: 12px; border: none; border-radius: 6px; background: var(--primary); color: white; font-weight: 600; cursor: pointer;">Gửi yêu cầu</button>
            </form>
        </div>
    </div>
    
    <script>
        function openContactModal() {
            document.getElementById('contactModal').classList.add('active');
        }
        function closeContactModal() {
            document.getElementById('contactModal').classList.remove('active');
        }
        // Close when clicking outside
        window.onclick = function(event) {
            var modal = document.getElementById('contactModal');
            if (event.target == modal) {
                closeContactModal();
            }
        }
    </script>
"""

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'
files = [r'fos-standard\gioi-thieu.html', r'fos-premium\gioi-thieu.html']

for file_path in files:
    full_path = os.path.join(base_dir, file_path)
    with io.open(full_path, 'r', encoding='utf-8') as f:
        html = f.read()
    
    # Replace closing </body> with modal + </body>
    html = html.replace('</body>', modal_html + '\n</body>')
    
    with io.open(full_path, 'w', encoding='utf-8') as f:
        f.write(html)

print("Added contact modal to FOS pages.")
