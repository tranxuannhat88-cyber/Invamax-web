import io
import os
import re

html_dir = '.'
for root, dirs, files in os.walk(html_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            original_html = html
            
            # Replace href="kham-benh-online/" with href="kham-benh-online/index.html"
            html = html.replace('href="kham-benh-online/"', 'href="kham-benh-online/index.html"')
            
            if html != original_html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(html)
                print(f"Fixed link in {file_path}")
