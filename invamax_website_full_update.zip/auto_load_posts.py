import io
import re

# 1. Update index.html
with io.open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Replace the content of the grid-3 container inside the "Kiến thức & Phân tích" section
# We'll use regex to find the grid-3 after "Kiến thức & Phân tích nổi bật"
pattern = r'(<h2>Kiến thức & Phân tích nổi bật</h2>.*?<div class="grid-3">).*?(</div>\s*<div style="text-align: center; margin-top: 40px;">)'
replacement = r'\1\n                <!-- Articles will be loaded here dynamically via JS -->\n                <p style="text-align: center; grid-column: 1 / -1; color: var(--text-muted); width: 100%;">Đang tải bài viết mới nhất...</p>\n            \2'

new_html = re.sub(pattern, replacement, html, flags=re.DOTALL)

# Add id to the grid-3
new_html = new_html.replace('<div class="grid-3">\n                <!-- Articles will be loaded here dynamically via JS -->', '<div class="grid-3" id="latest-posts-container">\n                <!-- Articles will be loaded here dynamically via JS -->')

if html != new_html:
    with io.open('index.html', 'w', encoding='utf-8') as f:
        f.write(new_html)
    print("Updated index.html container")
else:
    print("Could not update index.html")

# 2. Update main.js
js_path = 'assets/js/main.js'
with io.open(js_path, 'r', encoding='utf-8') as f:
    js_content = f.read()

js_code = """
// Auto-load latest posts from kien-thuc.html to index.html
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('latest-posts-container');
    if (!container) return; // Only run on pages that have this container

    fetch('kien-thuc.html')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.text();
        })
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const articles = doc.querySelectorAll('.image-card');
            
            if (articles.length > 0) {
                container.innerHTML = ''; // Clear loading text
                
                // Take up to 3 latest articles
                for (let i = 0; i < Math.min(3, articles.length); i++) {
                    const article = articles[i].cloneNode(true);
                    // Optionally fix lucide icons inside cloned nodes if they were already rendered
                    // Or we just call lucide.createIcons() later
                    container.appendChild(article);
                }
                
                // Re-initialize lucide icons for the newly injected HTML
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            } else {
                container.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">Chưa có bài viết nào.</p>';
            }
        })
        .catch(error => {
            console.error('Lỗi khi tải bài viết:', error);
            // Ignore error UI if it's just CORS from file:/// protocol, so user doesn't see ugly text locally
            // But we can put a gentle fallback
            container.innerHTML = '<p style="text-align: center; grid-column: 1 / -1; color: var(--text-muted);">Không thể tự động tải bài viết (Do chặn CORS trên máy tính). Khi đưa lên mạng web sẽ hoạt động bình thường.</p>';
        });
});
"""

if "latest-posts-container" not in js_content:
    js_content += "\n" + js_code
    with io.open(js_path, 'w', encoding='utf-8') as f:
        f.write(js_content)
    print("Added script to main.js")
else:
    print("Script already exists in main.js")
