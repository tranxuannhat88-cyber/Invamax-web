import io
import re

file_path = 'san-pham.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

target = r'<input type="file" id="quoteFile" class="form-control" name="file" accept="image/\*,\.pdf,\.doc,\.docx,\.xls,\.xlsx" style="padding: 10px;">\s*<small style="color: var\(--text-muted\); display: block; margin-top: 5px;">Hỗ trợ: JPG, PNG, PDF, DOC, XLS \(Tối đa 5MB\)</small>'

replacement = """<input type="file" id="quoteFile" class="form-control" name="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" style="padding: 10px;" multiple onchange="if(this.files.length > 2) { alert('Bạn chỉ được chọn tối đa 2 file đính kèm.'); this.value = ''; }">
                    <small style="color: var(--text-muted); display: block; margin-top: 5px;">Hỗ trợ: JPG, PNG, PDF, DOC, XLS (Tối đa 5MB/file - Chọn tối đa 2 file)</small>"""

html = re.sub(target, replacement, html)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated san-pham.html to allow max 2 files.")
