import re

with open('kham-benh-online/assets/js/questions_data.js', 'r', encoding='utf-8') as f:
    content = f.read()

ids = re.findall(r'\[\s*\"([A-F][0-9]{2})\"', content)
ids = sorted(list(set(ids)))

with open('update_gas.py', 'w', encoding='utf-8') as out:
    out.write('ids = ' + str(ids) + '\n')
