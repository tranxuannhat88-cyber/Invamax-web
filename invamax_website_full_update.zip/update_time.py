import io

file_path = r"kham-benh-online\gioi-thieu.html"

try:
    with io.open(file_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # The text to replace
    html = html.replace('5 phút', '~20 phút')
    
    with io.open(file_path, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated kham-benh-online/gioi-thieu.html")
except Exception as e:
    print("Error HTML:", e)
