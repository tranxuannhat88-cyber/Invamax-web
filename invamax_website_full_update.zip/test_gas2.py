import urllib.request
import json
import io

url = 'https://script.google.com/macros/s/AKfycbwINtrEt8nfP0lzCeTKAbmCgUzsgGs_EkGdmEKjQQfxKubCoIAnhivJK0mNnuHFd4Ds/exec'
data = {
    'formType': 'contact',
    'hoTen': 'Test Bot'
}

req = urllib.request.Request(url, method='POST')
req.add_header('Content-Type', 'text/plain;charset=utf-8')
jsondata = json.dumps(data).encode('utf-8')
req.add_header('Content-Length', len(jsondata))

try:
    response = urllib.request.urlopen(req, jsondata)
    body = response.read().decode('utf-8')
    with io.open("gas_response.html", "w", encoding="utf-8") as f:
        f.write(body)
    print("Success. Saved to gas_response.html")
except urllib.error.HTTPError as e:
    print("HTTP Error:", e.code)
    body = e.read().decode('utf-8')
    with io.open("gas_response.html", "w", encoding="utf-8") as f:
        f.write(body)
    print("Error body saved to gas_response.html")
except Exception as e:
    print("Error:", e)
