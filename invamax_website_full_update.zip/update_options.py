import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    old_options = '''<select name="quyMo">
                            <option value="Dưới 50 người">Dưới 50 người</option>
                            <option value="50 - 200 người">50 - 200 người</option>
                            <option value="200 - 500 người">200 - 500 người</option>
                            <option value="Trên 500 người">Trên 500 người</option>
                        </select>'''
    
    new_options = '''<select name="quyMo">
                            <option value="Dưới 50 người">Dưới 50 người</option>
                            <option value="50 ~ 100 người">50 ~ 100 người</option>
                            <option value="101 ~ 200 người">101 ~ 200 người</option>
                            <option value="Trên 200 người">Trên 200 người</option>
                        </select>'''

    if old_options in html:
        html = html.replace(old_options, new_options)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html options")
    else:
        print("Old options not found!")
except Exception as e:
    print("Error HTML:", e)
