import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The HTML to replace
    old_div = '<div style="margin-top: 40px; padding: 25px; background: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; text-align: center;">'
    new_div = '<div style="margin-top: 40px; padding: 25px; background: rgba(255, 107, 0, 0.05); border: 1px solid rgba(255, 107, 0, 0.2); border-radius: 8px; text-align: center;">'
    
    old_p = '<p style="color: #be123c; font-weight: 600; font-size: 1.1rem; margin: 0;">Hệ quả:'
    new_p = '<p style="color: var(--text-light); font-weight: 600; font-size: 1.1rem; margin: 0;"><span style="color: var(--primary);">Hệ quả:</span>'

    if old_div in html and old_p in html:
        html = html.replace(old_div, new_div)
        html = html.replace(old_p, new_p)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old HTML in index.html")
except Exception as e:
    print("Error HTML:", e)
