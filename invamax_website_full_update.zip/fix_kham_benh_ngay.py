import io
import os
import re

html_dir = '.'
for root, dirs, files in os.walk(html_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            original_html = html
            
            # 1. Fix broken stretched-link HTML
            html = html.replace(
                'class="btn btn-outline stretched-link" style="class="btn btn-outline stretched-link" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>',
                'class="btn btn-outline stretched-link" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>'
            )
            html = html.replace(
                'class="btn btn-outline stretched-link" style="class="btn btn-outline" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>',
                'class="btn btn-outline stretched-link" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>'
            )
            
            # 2. Revert Khám bệnh ngay
            if 'href="kham-benh-online/"' in html:
                html = html.replace(
                    '<a href="kham-benh-online/" class="btn btn-primary" style="text-align: center; padding: 10px 0;">Liên hệ tư vấn</a>',
                    '<a href="kham-benh-online/" class="btn btn-primary" style="text-align: center; padding: 10px 0;">Khám bệnh ngay</a>'
                )

            if html != original_html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(html)
                print(f"Fixed {file_path}")
