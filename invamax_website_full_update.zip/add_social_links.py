import io
import re
import os

root_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

target_pattern = r'(<div class="contact-item">\s*<i data-lucide="mail"></i>\s*<span>info@invamax\.com</span>\s*</div>\s*</div>\s*)(</div>)'

replacement = r'''\1<div class="social-links" style="margin-top: 24px; display: flex; gap: 16px;">
                        <a href="https://www.linkedin.com/in/xuannhattran/" target="_blank" style="color: var(--text-muted); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.05); transition: all 0.3s;" onmouseover="this.style.background='var(--primary)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.05)'; this.style.color='var(--text-muted)';">
                            <i data-lucide="linkedin" style="width: 20px; height: 20px;"></i>
                        </a>
                        <a href="https://www.facebook.com/invamax.vanhanhtinhgon" target="_blank" style="color: var(--text-muted); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.05); transition: all 0.3s;" onmouseover="this.style.background='var(--primary)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.05)'; this.style.color='var(--text-muted)';">
                            <i data-lucide="facebook" style="width: 20px; height: 20px;"></i>
                        </a>
                    </div>
                \2'''

count = 0
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            # Use regex to insert the social block
            new_html = re.sub(target_pattern, replacement, html)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Updated {count} html files.")
