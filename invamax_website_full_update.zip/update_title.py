import io

index_html = r"index.html"
style_css = r"assets\css\style.css"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # Define the old hero section start
    old_hero_start = '''    <section class="hero">
        <div class="container hero-content">
            <div class="hero-text">
                <h1>INVAMAX<br>Thiết kế & Chuyển đổi Mô hình vận hành nhà máy</h1>'''
    
    # Define the new hero section start
    new_hero_start = '''    <section class="hero">
        <div class="container">
            <h1 class="hero-main-title">INVAMAX<br>Thiết kế & Chuyển đổi Mô hình vận hành nhà máy</h1>
            <div class="hero-content">
                <div class="hero-text">'''

    if old_hero_start in html:
        html = html.replace(old_hero_start, new_hero_start)
        
        # We need to add one more closing </div> before </section> for the hero section
        # The old structure was: <section> <div container hero-content> <div hero-text>...</div> <div hero-image>...</div> </div> </section>
        # The new structure is: <section> <div container> <h1>...</h1> <div hero-content> <div hero-text>...</div> <div hero-image>...</div> </div> </div> </section>
        
        # Find the end of hero section to inject the closing div
        old_hero_end = '''            </div>
        </div>
    </section>'''
        new_hero_end = '''            </div>
            </div>
        </div>
    </section>'''
        html = html.replace(old_hero_end, new_hero_end)
        
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old hero start string in index.html")
except Exception as e:
    print("Error HTML:", e)

# Add CSS for hero-main-title
try:
    with io.open(style_css, 'a', encoding='utf-8') as f:
        css = '''
.hero-main-title {
    font-size: 3.5rem;
    line-height: 1.25;
    margin-bottom: 40px;
    letter-spacing: -1px;
    position: relative;
    z-index: 2;
}
@media (max-width: 768px) {
    .hero-main-title {
        font-size: 2.5rem;
    }
}
'''
        f.write(css)
    print("Updated style.css")
except Exception as e:
    print("Error CSS:", e)
