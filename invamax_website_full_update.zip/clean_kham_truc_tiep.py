import io
import re

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Remove the two lines and the extra margin
# Replace:
# <span class="section-subtitle">Giải pháp quản trị sản xuất & không gian làm việc Lean</span>
# <h1 style="font-size: 2.5rem; margin-bottom: 24px; text-transform: uppercase;">Khám Bệnh Trực Tiếp Tại Nhà Máy</h1>
# <p style="font-size: 1.2rem; color: var(--primary); font-weight: bold; max-width: 800px; margin: 0 auto;">Xây nền vững - Vận hành nhẹ</p>
# With just the h1, and no margin-bottom.

pattern = r'<span class="section-subtitle">Giải pháp quản trị sản xuất & không gian làm việc Lean</span>\s*<h1 style="font-size: 2.5rem; margin-bottom: 24px; text-transform: uppercase;">Khám Bệnh Trực Tiếp Tại Nhà Máy</h1>\s*<p style="font-size: 1.2rem; color: var\(--primary\); font-weight: bold; max-width: 800px; margin: 0 auto;">Xây nền vững - Vận hành nhẹ</p>'
new_content = '<h1 style="font-size: 2.5rem; margin-bottom: 0; text-transform: uppercase;">Khám Bệnh Trực Tiếp Tại Nhà Máy</h1>'

html = re.sub(pattern, new_content, html)

# 2. Reduce the padding-bottom of .intro-hero to make it closer to the next section
css_pattern = r'\.intro-hero \{\s*padding: 120px 0 60px;'
css_new = r'.intro-hero {\n            padding: 120px 0 20px;'
html = re.sub(css_pattern, css_new, html)

# Also reduce the padding-top of the next section if needed, it's currently padding-top: 40px;
section_pattern = r'<section class="intro-section" style="padding-top: 40px;">'
section_new = r'<section class="intro-section" style="padding-top: 10px;">'
html = html.replace(section_pattern, section_new)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Removed lines and reduced spacing.")
