import io
import re

js_path = r"assets\js\quote.js"
with io.open(js_path, 'r', encoding='utf-8') as f:
    js_content = f.read()

# Update closeQuoteModal
old_close = """function closeQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.remove('active');
        // Reset form
        document.getElementById('quoteForm').reset();
        document.getElementById('quoteSuccess').style.display = 'none';
        document.getElementById('quoteLoading').style.display = 'none';
        document.getElementById('btnSubmitQuote').style.display = 'block';
    }
}"""
new_close = """function closeQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.remove('active');
        // Reset form
        document.getElementById('quoteForm').style.display = 'block';
        document.getElementById('quoteForm').reset();
        document.getElementById('quoteSuccess').style.display = 'none';
        document.getElementById('quoteLoading').style.display = 'none';
        document.getElementById('btnSubmitQuote').style.display = 'block';
    }
}"""

if old_close in js_content:
    js_content = js_content.replace(old_close, new_close)

# Update submit success
old_success = """        if (result.status === 'success') {
            loading.style.display = 'none';
            successMsg.style.display = 'block';
            setTimeout(closeQuoteModal, 3000);
        }"""
new_success = """        if (result.status === 'success') {
            loading.style.display = 'none';
            document.getElementById('quoteForm').style.display = 'none';
            successMsg.style.display = 'block';
            lucide.createIcons();
        }"""

if old_success in js_content:
    js_content = js_content.replace(old_success, new_success)

with io.open(js_path, 'w', encoding='utf-8') as f:
    f.write(js_content)
print("Updated quote.js properly")
