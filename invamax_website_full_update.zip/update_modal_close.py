import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Remove click outside to close
    old_div = '<div id="contactModal" class="modal-overlay" onclick="if(event.target===this) closeContactModal()">'
    new_div = '<div id="contactModal" class="modal-overlay">'
    
    html = html.replace(old_div, new_div)
    
    # 2. Fix X button to be visible. Lucide might be failing to render it for some reason. 
    # Let's replace <i data-lucide="x"></i> with a standard Unicode X or SVG.
    old_btn = '<button class="modal-close" onclick="closeContactModal()"><i data-lucide="x"></i></button>'
    new_btn = '<button class="modal-close" onclick="closeContactModal()" style="font-size: 24px; line-height: 1; font-weight: bold;">&times;</button>'
    
    html = html.replace(old_btn, new_btn)

    with io.open(index_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated index.html")
except Exception as e:
    print("Error HTML:", e)
