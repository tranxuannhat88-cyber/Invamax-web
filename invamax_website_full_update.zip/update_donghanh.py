import io
import re
import os

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'
file_path = os.path.join(base_dir, r'dong-hanh-quan-tri\gioi-thieu.html')

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Replacement block for intro-grid
new_intro_grid = """<div class="intro-grid">
                <div>
                    <div class="intro-card">
                        <h3><i data-lucide="target"></i> Thách thức sau cải tiến</h3>
                        <p style="margin-bottom: 12px;">Đa số các nhà máy thường gặp khó khăn trong việc duy trì thành quả sau khi dự án Lean kết thúc:</p>
                        <ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li>Phong trào 5S, Lean bị nguội lạnh và quay về thói quen cũ.</li>
                            <li>Ban Giám đốc quá bận rộn, không thể kiểm tra xưởng mỗi ngày.</li>
                            <li>Hệ thống vận hành đi chệch hướng nhưng không được phát hiện kịp thời.</li>
                            <li>Cần chuyên gia cấp cao (COO) để tham mưu nhưng chưa sẵn sàng trả lương full-time.</li>
                        </ul>
                    </div>
                    
                    <div class="intro-card">
                        <h3><i data-lucide="mouse-pointer-click"></i> Mô hình hoạt động</h3>
                        <p style="margin-bottom: 12px;">Chuyên gia INVAMAX sẽ đóng vai trò như một Giám đốc vận hành Part-time:</p>
                        <ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li><strong>Audit định kỳ:</strong> Đánh giá hiện trường hàng tháng để đảm bảo tiêu chuẩn FOS được duy trì.</li>
                            <li><strong>Họp chiến lược:</strong> Tham gia họp Ban Giám đốc để phân tích số liệu KPIs và đưa ra quyết sách.</li>
                            <li><strong>Cố vấn chuyên môn:</strong> Hỗ trợ Ban Giám đốc xử lý các sự cố vận hành phức tạp phát sinh.</li>
                            <li><strong>Cập nhật tri thức:</strong> Đưa các công cụ, công nghệ quản trị mới nhất vào nhà máy.</li>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="intro-card" style=" height: 100%;">
                        <h3><i data-lucide="award"></i> Giá trị nhận được</h3>
                        <p>Sở hữu "bộ não" chuyên gia và duy trì hệ thống cải tiến liên tục với chi phí tối ưu nhất.</p>
                        
                        <ul style="list-style-type: none; padding-left: 0; color: var(--text-muted); line-height: 1.8; margin-top: 25px;">
                            <li style="margin-bottom: 15px; display: flex; align-items: flex-start;"><span style="color: #ea580c; font-weight: bold; margin-right: 10px; margin-top: 2px;">✓</span> <strong>An tâm uỷ quyền:</strong> Ban Giám đốc hoàn toàn yên tâm khi hệ thống được giám sát bởi bên thứ ba khách quan.</li>
                            <li style="margin-bottom: 15px; display: flex; align-items: flex-start;"><span style="color: #ea580c; font-weight: bold; margin-right: 10px; margin-top: 2px;">✓</span> <strong>Duy trì văn hoá Kaizen:</strong> Đảm bảo ngọn lửa cải tiến luôn cháy trong đội ngũ quản lý cấp trung.</li>
                            <li style="margin-bottom: 15px; display: flex; align-items: flex-start;"><span style="color: #ea580c; font-weight: bold; margin-right: 10px; margin-top: 2px;">✓</span> <strong>Tối ưu chi phí:</strong> Tiết kiệm đến 80% so với việc thuê một Giám đốc Vận hành (COO) toàn thời gian.</li>
                            <li style="margin-bottom: 15px; display: flex; align-items: flex-start;"><span style="color: #ea580c; font-weight: bold; margin-right: 10px; margin-top: 2px;">✓</span> <strong>Phát triển bền vững:</strong> Nhà máy không chỉ giữ vững thành quả mà còn liên tục trưởng thành.</li>
                        </ul>
                        
                        <div style="background-color: #fff; padding: 10px; border-radius: 8px; margin-top: 30px;">
                            <div style="width: 100%; height: 180px; background-color: #f8fafc; border-radius: 4px; border: 1px solid #e2e8f0; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #64748b; font-size: 1.05rem; font-weight: 500;">
                                <i data-lucide="shield-check" style="width: 54px; height: 54px; margin-bottom: 15px; opacity: 0.8; color: var(--primary);"></i>
                                Duy trì Hệ Điều Hành Bền Vững
                            </div>
                        </div>
                    </div>
                </div>
            </div>"""

grid_pattern = r'<div class="intro-grid">.*?</div>\s*</div>\s*</div>\s*</div>'
html = re.sub(grid_pattern, new_intro_grid, html, flags=re.DOTALL)

# Update CTA text
html = html.replace("Bạn đã sẵn sàng chẩn đoán nhà máy của mình?", "Bạn cần một chuyên gia đồng hành định kỳ?")

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated dong-hanh-quan-tri/gioi-thieu.html")
