import io
import re
import os

# 1. Update text in all HTML files
html_dir = '.'
for root, dirs, files in os.walk(html_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            original_html = html
            html = html.replace('>Khám bệnh ngay<', '>Liên hệ tư vấn<')
            html = html.replace('>Liên hệ để được tư vấn<', '>Liên hệ tư vấn<')
            
            if html != original_html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(html)
                print(f"Updated text in {file_path}")

# 2. Update style.css
css_path = r'assets\css\style.css'
with io.open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Add button card hover synchronization rules
hover_button_css = """
/* Synchronized neutral state for buttons inside cards */
.card .btn-outline, .intro-card .btn-outline {
    border-color: rgba(255, 255, 255, 0.2);
    color: #a0aec0;
    transition: all 0.3s ease;
}
.card .btn-primary, .intro-card .btn-primary {
    background-color: rgba(255, 255, 255, 0.1);
    color: #e2e8f0;
    transition: all 0.3s ease;
}

/* Hover state for buttons inside cards */
.card:hover .btn-outline, .intro-card:hover .btn-outline {
    border-color: var(--primary);
    color: var(--primary);
}
.card:hover .btn-outline:hover, .intro-card:hover .btn-outline:hover {
    background-color: var(--primary);
    color: var(--text-white);
}

.card:hover .btn-primary, .intro-card:hover .btn-primary {
    background-color: var(--primary);
    color: var(--text-white);
}
.card:hover .btn-primary:hover, .intro-card:hover .btn-primary:hover {
    background-color: var(--primary-hover);
}
"""

if "Synchronized neutral state for buttons inside cards" not in css_content:
    css_content += hover_button_css
    with io.open(css_path, 'w', encoding='utf-8') as f:
        f.write(css_content)
    print("Added synchronized button hover rules to style.css")
else:
    print("Rules already exist in style.css")

