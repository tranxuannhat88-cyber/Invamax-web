import io
import re

main_js_path = r"assets\js\main.js"
quote_js_path = r"assets\js\quote.js"

# Remove from main.js
try:
    with io.open(main_js_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Use regex to remove the if block
    content = re.sub(
        r"if\s*\(GOOGLE_SCRIPT_URL === \".*?\"\)\s*\{\s*alert\(\"Tính năng đang được thiết lập \(Thiếu URL Webhook\)\.\"\);\s*return;\s*\}",
        "",
        content
    )
    
    with io.open(main_js_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Fixed main.js")
except Exception as e:
    print("Error main.js:", e)

# Remove from quote.js
try:
    with io.open(quote_js_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Use regex to remove the if block
    content = re.sub(
        r"if\s*\(GAS_URL === \'.*?\'\)\s*\{\s*alert\('Vui lòng cấu hình Google Apps Script URL trong file assets/js/quote\.js'\);\s*return;\s*\}",
        "",
        content
    )
    
    with io.open(quote_js_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Fixed quote.js")
except Exception as e:
    print("Error quote.js:", e)
