import io

js_path = r"assets\js\quote.js"

with io.open(js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Add formType: 'quote' to the data object
old_data_obj = """    const data = {
        name: formData.get('name'),"""

new_data_obj = """    const data = {
        formType: 'quote',
        name: formData.get('name'),"""

if old_data_obj in content:
    content = content.replace(old_data_obj, new_data_obj)
    with io.open(js_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Updated quote.js successfully")
else:
    print("Could not find data object in quote.js")
