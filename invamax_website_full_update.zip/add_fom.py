import io
import re

with io.open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

new_section = """
    <!-- Factory Operating Model Section -->
    <section class="section section-darker" style="background-color: #f1f5f9;">
        <div class="container">
            <div class="section-header">
                <span class="section-subtitle" style="color: var(--primary); font-weight: bold;">Tài sản trí tuệ của INVAMAX</span>
                <h2 class="section-title" style="font-size: 2.2rem;">Factory Operating Model™<br>Mô hình vận hành nhà máy thế hệ mới</h2>
                <p class="section-desc" style="max-width: 800px; margin: 0 auto;">
                    <strong>Bạn không cần thêm một hệ thống nữa. Bạn cần một mô hình vận hành tốt hơn.</strong><br>
                    Không phải framework. Đây là logic thiết kế cách nhà máy tạo ra quyết định, kỷ luật và hiệu suất, giúp nhà máy trở thành một hệ thống kinh doanh kết nối thay vì các phòng ban rời rạc.
                </p>
            </div>
            
            <div class="grid-3" style="margin-top: 40px;">
                <div class="card" style="border-top: 4px solid var(--primary);">
                    <div class="card-icon" style="color: var(--primary);"><i data-lucide="target"></i></div>
                    <h3>Chiến lược & Tổ chức</h3>
                    <p>Thiết kế luồng quyết định và phân quyền rõ ràng. Kết nối chiến lược kinh doanh vào mọi hoạt động tại hiện trường.</p>
                </div>
                <div class="card" style="border-top: 4px solid var(--primary);">
                    <div class="card-icon" style="color: var(--primary);"><i data-lucide="activity"></i></div>
                    <h3>Dòng chảy & Nhịp vận hành</h3>
                    <p>Xây dựng dòng chảy giá trị không tắc nghẽn và nhịp vận hành chuẩn mực (cadence) từ ca sản xuất đến ban giám đốc.</p>
                </div>
                <div class="card" style="border-top: 4px solid var(--primary);">
                    <div class="card-icon" style="color: var(--primary);"><i data-lucide="cpu"></i></div>
                    <h3>Thông tin & Trí tuệ</h3>
                    <p>Dữ liệu minh bạch, ứng dụng AI để ra quyết định, tiến tới cấp độ nhà máy tự học (Self-Improving Factory).</p>
                </div>
            </div>
        </div>
    </section>
"""

# Insert after Hero section
# Find </section> after "Hero Section"
hero_end = html.find('</section>', html.find('<!-- Hero Section -->')) + 10
new_html = html[:hero_end] + "\n" + new_section + html[hero_end:]

with io.open('index.html', 'w', encoding='utf-8') as f:
    f.write(new_html)

print("Added Factory Operating Model section")
