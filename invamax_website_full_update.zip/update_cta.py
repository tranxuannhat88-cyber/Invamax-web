import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Update padding
    old_section = '<section class="section" style="background: var(--primary); color: white;">'
    new_section = '<section class="section" style="background: var(--primary); color: white; padding: 60px 0;">'
    html = html.replace(old_section, new_section)

    # 2. Update max-width
    old_container = '<div class="container" style="text-align: center; max-width: 800px;">'
    new_container = '<div class="container" style="text-align: center; max-width: 1100px;">'
    html = html.replace(old_container, new_container)

    # 3. Remove the second button
    old_buttons = '''            <div style="display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
                <button onclick="openContactModal()" class="btn" style="background: white; color: var(--primary); padding: 15px 30px; font-size: 1.1rem; font-weight: bold; border:none;">Liên hệ để đánh giá nhà máy của bạn</button>
                <a href="#contact" class="btn" style="background: transparent; border: 2px solid white; color: white; padding: 15px 30px; font-size: 1.1rem; font-weight: bold;">Liên hệ INVAMAX</a>
            </div>'''
            
    new_buttons = '''            <div style="display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
                <button onclick="openContactModal()" class="btn" style="background: white; color: var(--primary); padding: 15px 30px; font-size: 1.1rem; font-weight: bold; border:none;">Liên hệ để đánh giá nhà máy của bạn</button>
            </div>'''
            
    if old_buttons in html:
        html = html.replace(old_buttons, new_buttons)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the buttons in index.html")
except Exception as e:
    print("Error HTML:", e)
