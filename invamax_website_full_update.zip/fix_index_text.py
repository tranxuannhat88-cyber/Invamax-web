import io

file_path = 'index.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Thay thế các trường hợp chưa được thay ở index.html
html = html.replace('Liên hệ để được tư vấn', 'Liên hệ tư vấn')

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated index.html")
