import io
import re

index_html = r"index.html"
dich_vu_html = r"dich-vu.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        idx_html = f.read()

    # Extract modal block from index.html
    # It starts at <!-- Contact Modal --> and ends at the end of the file or before </body>
    modal_start = idx_html.find('<!-- Contact Modal -->')
    if modal_start != -1:
        body_end = idx_html.find('</body>')
        if body_end != -1:
            modal_html = idx_html[modal_start:body_end].strip() + "\n\n"
        else:
            modal_html = idx_html[modal_start:].strip() + "\n\n"
    else:
        print("Modal not found in index")
        modal_html = ""

    with io.open(dich_vu_html, 'r', encoding='utf-8') as f:
        dv_html = f.read()

    # 1. Inject modal into dich-vu.html
    if 'id="contactModal"' not in dv_html and modal_html:
        body_end_dv = dv_html.find('</body>')
        if body_end_dv != -1:
            dv_html = dv_html[:body_end_dv] + modal_html + dv_html[body_end_dv:]

    # 2. Fix the grid-3 to grid-2 and center it
    # We find the section for Khám bệnh nhà máy
    # It starts with <h2 class="section-title">Khám bệnh nhà máy</h2> and then a <div class="grid-3">
    search_str = '<h2 class="section-title">Khám bệnh nhà máy</h2>'
    pos = dv_html.find(search_str)
    if pos != -1:
        grid3_pos = dv_html.find('<div class="grid-3">', pos)
        if grid3_pos != -1 and grid3_pos < pos + 500: # ensure it's the one right after
            dv_html = dv_html[:grid3_pos] + '<div class="grid-2" style="max-width: 900px; margin: 0 auto;">' + dv_html[grid3_pos + len('<div class="grid-3">'):]
            
    # Also just in case I already changed it to <div class="grid-2"> but without style:
    if '<div class="grid-2">\n                    <div class="card"' in dv_html:
        dv_html = dv_html.replace('<div class="grid-2">\n                    <div class="card"', '<div class="grid-2" style="max-width: 900px; margin: 0 auto;">\n                    <div class="card"')

    # 3. Update the button for the second card (Khám bệnh trực tiếp tại nhà máy)
    # The old button block might be:
    # <div style="margin-top: auto; padding-top: 1rem;">
    #     <button onclick="openContactModal()" class="btn btn-outline" style="width: 100%; text-align: center; display: block; border-radius: 99px;">Liên hệ để được tư vấn</button>
    # </div>
    
    old_btn_block = '''<div style="margin-top: auto; padding-top: 1rem;">
                            <button onclick="openContactModal()" class="btn btn-outline" style="width: 100%; text-align: center; display: block; border-radius: 99px;">Liên hệ để được tư vấn</button>
                        </div>'''
                        
    # It might have different spacing, let's use regex
    btn_pattern = r'<div style="margin-top: auto; padding-top: 1rem;">\s*<button onclick="openContactModal\(\)".*?>Liên hệ để được tư vấn<\/button>\s*<\/div>'
    
    new_btn_block = '''<div style="margin-top: auto; padding-top: 1rem; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                            <a href="kham-benh-truc-tiep/gioi-thieu.html" class="btn btn-outline" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>
                            <button onclick="openContactModal()" class="btn btn-primary" style="text-align: center; padding: 10px 0;">Liên hệ để được tư vấn</button>
                        </div>'''
                        
    dv_html = re.sub(btn_pattern, new_btn_block, dv_html)

    # What if it still has the a tag from before?
    btn_pattern2 = r'<div style="margin-top: auto; padding-top: 1rem;">\s*<a href="mailto:.*?>Liên hệ tư vấn<\/a>\s*<\/div>'
    dv_html = re.sub(btn_pattern2, new_btn_block, dv_html)

    with io.open(dich_vu_html, 'w', encoding='utf-8') as f:
        f.write(dv_html)
    print("Fixed dich-vu.html")

except Exception as e:
    print("Error:", e)
