import io
import os
import glob
import re

dich_vu_html = "dich-vu.html"
try:
    with io.open(dich_vu_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # Update description of 'Khám bệnh online'
    old_desc = 'Trao đổi trực tuyến 1-1 với chuyên gia, chẩn đoán nhanh các vấn đề nổi cộm dựa trên dữ liệu bạn cung cấp.'
    new_desc = 'Doanh nghiệp tự đánh giá tình trạng nhà máy thông qua bộ câu hỏi chuẩn hóa của INVAMAX để nhận diện nhanh các lỗ hổng quản trị và lãng phí.'
    if old_desc in html:
        html = html.replace(old_desc, new_desc)
        print("Updated Kham benh online description")
        
    # Remove the 'Giải quyết vấn đề / Cải tiến' card
    # The card starts with <div class="card" style="border-top: 4px solid var(--primary);"> and has 'Giải quyết vấn đề / Cải tiến' inside
    # We can match the entire card div
    card_pattern = r'<div class="card" style="border-top: 4px solid var\(--primary\);">(?:(?!<div class="card").)*?Giải quyết vấn đề \/ Cải tiến(?:(?!<div class="card").)*?<\/div>'
    match = re.search(card_pattern, html, re.DOTALL)
    if match:
        html = html.replace(match.group(0), "")
        print("Removed Giai quyet van de card")
        
    # Now there are only 2 cards, so we should change .grid-3 to .grid-2 for this section
    # Let's find the grid-3 that contains these cards and change to grid-2
    # The grid-3 is right before the first card
    grid_pattern = r'<div class="grid-3"(.*?)(?=<div class="card")'
    html = re.sub(grid_pattern, r'<div class="grid-2"\1', html, count=1)
    
    with io.open(dich_vu_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated dich-vu.html")

except Exception as e:
    print(f"Error processing dich-vu.html: {e}")
