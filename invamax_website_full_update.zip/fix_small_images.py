import io
import re

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Restore the intro-grid
html = html.replace('<div style="display: flex; flex-direction: column; gap: 40px; margin-bottom: 60px;">', '<div class="intro-grid" style="align-items: stretch; margin-bottom: 60px;">')

# 2. Fix Card 1
card1_pattern = r'<div class="intro-card" style="margin-bottom: 0; display: flex; align-items: center; gap: 40px; flex-wrap: wrap;">(.*?)<div style="flex: 1; min-width: 300px; text-align: center;">\s*<img src="\.\./assets/images/expert_inspection\.jpg" alt="Chuyên gia INVAMAX khảo sát thực tế" style="width: 100%; max-width: 400px; border-radius: 12px; box-shadow: 0 10px 30px -10px rgba\(0,0,0,0\.5\);">\s*</div>\s*</div>'

def replacer1(match):
    # Extract the text content block
    text_content = match.group(1).strip()
    # Remove the min-width from the text block
    text_content = text_content.replace('<div style="flex: 1; min-width: 300px;">', '<div style="flex: 1;">')
    
    return f"""<div class="intro-card" style="margin-bottom: 0; display: flex; align-items: center; gap: 24px;">
                    {text_content}
                    <div style="width: 160px; flex-shrink: 0; display: none; @media (min-width: 1200px) {{ display: block; }}">
                        <img src="../assets/images/expert_inspection.jpg" alt="Chuyên gia INVAMAX khảo sát thực tế" style="width: 100%; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); object-fit: cover; aspect-ratio: 1/1;">
                    </div>
                </div>"""
                
# Actually inline media query isn't valid CSS for a style attribute. I will just use a class or rely on the fact that flex-wrap is OFF, so it just squishes. Or better yet, just flex-shrink: 0 and if the screen is too small, it wraps the outer grid first. The outer grid is responsive (.intro-grid drops to 1fr on mobile). So we just need flex-shrink: 0.

def replacer1_clean(match):
    text_content = match.group(1).strip()
    text_content = text_content.replace('<div style="flex: 1; min-width: 300px;">', '<div style="flex: 1;">')
    
    return f"""<div class="intro-card" style="margin-bottom: 0; display: flex; align-items: center; gap: 20px;">
                    {text_content}
                    <div style="width: 140px; flex-shrink: 0;">
                        <img src="../assets/images/expert_inspection.jpg" alt="Chuyên gia INVAMAX" style="width: 100%; height: 140px; object-fit: cover; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                    </div>
                </div>"""

html = re.sub(card1_pattern, replacer1_clean, html, flags=re.DOTALL)

# 3. Fix Card 2
card2_pattern = r'<div class="intro-card" style="margin-bottom: 0; background-color: rgba\(255,255,255,0\.02\); display: flex; align-items: center; gap: 40px; flex-wrap: wrap;">(.*?)<div style="flex: 1; min-width: 300px; text-align: center;">\s*<img src="\.\./assets/images/factory_report\.jpg" alt="Báo cáo hiện trạng nhà máy" style="width: 100%; max-width: 400px; border-radius: 12px; box-shadow: 0 10px 30px -10px rgba\(0,0,0,0\.5\);">\s*</div>\s*</div>'

def replacer2_clean(match):
    text_content = match.group(1).strip()
    text_content = text_content.replace('<div style="flex: 1; min-width: 300px;">', '<div style="flex: 1;">')
    
    return f"""<div class="intro-card" style="margin-bottom: 0; background-color: rgba(255,255,255,0.02); display: flex; align-items: center; gap: 20px;">
                    {text_content}
                    <div style="width: 140px; flex-shrink: 0;">
                        <img src="../assets/images/factory_report.jpg" alt="Báo cáo nhà máy" style="width: 100%; height: 140px; object-fit: cover; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                    </div>
                </div>"""

html = re.sub(card2_pattern, replacer2_clean, html, flags=re.DOTALL)


with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Updated card layout to have small images side-by-side.")
