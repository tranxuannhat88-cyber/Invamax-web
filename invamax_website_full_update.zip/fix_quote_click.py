import io
import re

js_path = r"assets\js\quote.js"

with io.open(js_path, 'r', encoding='utf-8') as f:
    js_content = f.read()

# Remove the event listener block from openQuoteModal
old_open_func = """function openQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.add('active');
        // Add closing event on clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeQuoteModal();
            }
        });
    }
}"""

new_open_func = """function openQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.add('active');
    }
}"""

if old_open_func in js_content:
    js_content = js_content.replace(old_open_func, new_open_func)
else:
    # Use regex if exact string mismatch
    js_content = re.sub(
        r"modal\.addEventListener\('click', function\(e\) \{[\s\S]*?\}\);",
        "",
        js_content
    )
    js_content = re.sub(r"// Add closing event on clicking outside\n*", "", js_content)

with io.open(js_path, 'w', encoding='utf-8') as f:
    f.write(js_content)
print("Fixed quote.js to disable outside click")
