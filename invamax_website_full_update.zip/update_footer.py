import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The text to replace
    old_text = 'Giải pháp vận hành tinh gọn, <br>hiệu suất cao cho nhà máy.'
    old_text_2 = 'Giải pháp vận hành tinh gọn, hiệu suất cao cho nhà máy.'
    
    new_text = 'Thiết kế & Chuyển đổi mô hình vận hành nhà máy'
    
    if old_text in html:
        html = html.replace(old_text, new_text)
    elif old_text_2 in html:
        html = html.replace(old_text_2, new_text)
        
    with io.open(index_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated index.html")
except Exception as e:
    print("Error HTML:", e)
