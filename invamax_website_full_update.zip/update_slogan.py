import io
import re
import os

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

pattern = r'<p class="text-muted mb-4">Giải pháp vận hành tinh gọn,\s*<br>hiệu suất cao cho nhà máy.</p>'
replacement = r'<p class="text-muted mb-4">Thiết kế & Chuyển đổi<br>Mô hình vận hành nhà máy.</p>'

count = 0
for root, dirs, files in os.walk(base_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            new_html = re.sub(pattern, replacement, html)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Updated footer slogan in {count} html files.")
