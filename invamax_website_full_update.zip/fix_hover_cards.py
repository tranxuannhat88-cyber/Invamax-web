import os
import io
import re

css_path = r"assets\css\style.css"

with io.open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Add hover effects to style.css
if "border-top: 4px solid transparent;" not in css_content:
    # Add transparent border to .card
    css_content = css_content.replace(
        "    border: 1px solid var(--border-color);",
        "    border: 1px solid var(--border-color);\n    border-top: 4px solid transparent;"
    )
    
    # Add hover effects
    hover_css = """
.card:hover, .intro-card:hover {
    border-top-color: var(--primary);
}
.card h3, .intro-card h3 {
    transition: color 0.3s ease;
}
.card:hover h3, .intro-card:hover h3 {
    color: var(--primary);
}
.card .card-icon, .intro-card .card-icon {
    transition: color 0.3s ease;
}
.card:hover .card-icon, .intro-card:hover .card-icon {
    color: var(--primary);
}
"""
    css_content += hover_css
    
    with io.open(css_path, 'w', encoding='utf-8') as f:
        f.write(css_content)
    print("Updated style.css")

# Strip inline styles from HTML files
def strip_inline_styles(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.html'):
                file_path = os.path.join(root, file)
                try:
                    with io.open(file_path, 'r', encoding='utf-8') as f:
                        html = f.read()
                    
                    original_html = html
                    # Remove border-top: 4px solid var(--primary); and similar
                    html = re.sub(r' style="border-top:\s*4px\s+solid\s+(?:var\(--primary\)|#fff|var\(--secondary\));?(.*?)"', r' style="\1"', html)
                    # Clean up empty style=""
                    html = html.replace(' style=""', '')
                    
                    # Remove color: var(--primary) from h3
                    html = re.sub(r'(<h3[^>]*?) style="([^"]*)color:\s*var\(--primary\);?([^"]*)"', r'\1 style="\2\3"', html)
                    # Clean up empty style="" for h3
                    html = html.replace(' style=""', '')

                    # Remove color: var(--primary) from card-icon
                    html = re.sub(r'(<div class="card-icon"[^>]*?) style="([^"]*)color:\s*var\(--primary\);?([^"]*)"', r'\1 style="\2\3"', html)
                    html = html.replace(' style=""', '')

                    # Remove inline background darker if any
                    html = re.sub(r' style="background-color:\s*var\(--bg-darker\);?"', '', html)
                    html = re.sub(r' style="\s*background-color:\s*var\(--bg-darker\);\s*"', '', html)
                    
                    if html != original_html:
                        with io.open(file_path, 'w', encoding='utf-8') as f:
                            f.write(html)
                        print(f"Cleaned {file_path}")
                except Exception as e:
                    print(f"Error on {file_path}: {e}")

strip_inline_styles('.')
