import io
import re

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

new_content = """
    <div class="intro-hero">
        <div class="container">
            <span class="section-subtitle">Giải pháp quản trị sản xuất & không gian làm việc Lean</span>
            <h1 style="font-size: 2.5rem; margin-bottom: 24px; text-transform: uppercase;">Khám Bệnh Trực Tiếp Tại Nhà Máy</h1>
            <p style="font-size: 1.2rem; color: var(--primary); font-weight: bold; max-width: 800px; margin: 0 auto;">Xây nền vững - Vận hành nhẹ</p>
        </div>
    </div>

    <section class="intro-section" style="padding-top: 40px;">
        <div class="container">
            <!-- 9 CĂN BỆNH -->
            <div style="text-align: center; margin-bottom: 50px;">
                <h2 style="font-size: 2.2rem; margin-bottom: 16px; text-transform: uppercase;">Nhà máy của bạn có đang mắc những <span style="color: var(--primary);">"Căn bệnh"</span> này?</h2>
                <p style="font-size: 1.1rem; color: var(--text-muted); max-width: 800px; margin: 0 auto;">Những dấu hiệu tưởng chừng nhỏ – nhưng đang âm thầm ăn mòn lợi nhuận và kìm hãm sự phát triển của nhà máy.</p>
            </div>

            <div style="background-color: var(--bg-card); border: 1px solid var(--border-color); border-radius: 12px; padding: 40px; margin-bottom: 60px;">
                <div style="background-color: #111; color: white; display: inline-block; padding: 8px 24px; border-radius: 4px; font-weight: bold; margin-top: -60px; margin-bottom: 30px; font-size: 1.2rem; border-left: 4px solid var(--primary);">
                    <span style="color: var(--primary); font-size: 1.4rem;">9</span> CĂN BỆNH PHỔ BIẾN ẨN GIẤU TRONG NHÀ MÁY
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 20px; text-align: center;">
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">1</div><i data-lucide="factory" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Nhà xưởng bừa bộn</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">2</div><i data-lucide="trending-down" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Năng suất lao động thấp</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">3</div><i data-lucide="settings-2" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Tỷ lệ lỗi cao, lỗi lặp lại</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">4</div><i data-lucide="package-open" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Tồn kho NVL, thành phẩm cao</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">5</div><i data-lucide="alert-triangle" style="width: 40px; height: 40px; margin-bottom: 15px; color: var(--primary);"></i><p style="font-size: 0.9rem; font-weight: bold;">Thường xuyên phát sinh vấn đề</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">6</div><i data-lucide="user-x" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Phụ thuộc vào một vài cá nhân</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">7</div><i data-lucide="bar-chart-2" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Thiếu thông tin để quản trị</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">8</div><i data-lucide="pie-chart" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Doanh thu tăng nhưng lợi nhuận không tăng</p></div>
                    <div><div style="color: var(--primary); font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">9</div><i data-lucide="laptop" style="width: 40px; height: 40px; margin-bottom: 15px;"></i><p style="font-size: 0.9rem; font-weight: bold;">Chủ nhà máy phải can thiệp thường xuyên</p></div>
                </div>
            </div>

            <!-- GIẢI PHÁP & BÁO CÁO -->
            <div class="intro-grid" style="align-items: stretch; margin-bottom: 60px;">
                <div class="intro-card" style="margin-bottom: 0;">
                    <h3 style="text-transform: uppercase;">Khám bệnh nhà máy cùng INVAMAX</h3>
                    <p style="color: var(--primary); font-weight: bold; font-size: 1.1rem; margin-bottom: 20px;">CHẨN ĐOÁN ĐÚNG – KÊ ĐƠN CHÍNH XÁC</p>
                    <p style="margin-bottom: 20px; color: var(--text-muted);">Trong 3 ngày, chuyên gia INVAMAX sẽ trực tiếp:</p>
                    <ul style="list-style: none; padding: 0; color: var(--text-muted); line-height: 2;">
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Đi thực địa toàn bộ nhà máy</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Đánh giá dòng chảy sản xuất</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Kiểm tra hệ thống quản lý</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Phân tích dữ liệu vận hành</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Phỏng vấn các cấp quản lý</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><i data-lucide="check-circle-2" style="color: var(--primary); width: 20px;"></i> Xác định nguyên nhân gốc của các vấn đề.</li>
                    </ul>
                </div>

                <div class="intro-card" style="margin-bottom: 0; background-color: rgba(255,255,255,0.02);">
                    <h3 style="text-transform: uppercase; color: var(--text-white);">Sau 3 ngày bạn nhận được</h3>
                    <p style="color: var(--primary); font-weight: bold; font-size: 1.1rem; margin-bottom: 30px; text-transform: uppercase;">Báo cáo hiện trạng nhà máy</p>
                    
                    <div style="display: flex; flex-direction: column; gap: 24px;">
                        <div style="display: flex; align-items: flex-start; gap: 16px;">
                            <div style="background: var(--primary); color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; flex-shrink: 0;">1</div>
                            <div>
                                <h4 style="margin-bottom: 4px;">Các vấn đề tồn tại và hậu quả</h4>
                            </div>
                        </div>
                        <div style="display: flex; align-items: flex-start; gap: 16px;">
                            <div style="background: var(--primary); color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; flex-shrink: 0;">2</div>
                            <div>
                                <h4 style="margin-bottom: 4px;">Nguyên nhân gốc rễ của từng vấn đề</h4>
                            </div>
                        </div>
                        <div style="display: flex; align-items: flex-start; gap: 16px;">
                            <div style="background: var(--primary); color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; flex-shrink: 0;">3</div>
                            <div>
                                <h4 style="margin-bottom: 4px;">Giải pháp xử lý, cải thiện</h4>
                            </div>
                        </div>
                        <div style="display: flex; align-items: flex-start; gap: 16px;">
                            <div style="background: var(--primary); color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; flex-shrink: 0;">4</div>
                            <div>
                                <h4 style="margin-bottom: 4px;">Lộ trình triển khai</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- WARNING BOX -->
            <div style="background: linear-gradient(135deg, #2a1610, #111); border: 1px solid var(--primary); border-radius: 12px; padding: 40px; display: flex; align-items: center; gap: 40px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 300px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem; margin-bottom: 10px; display: flex; align-items: center; gap: 12px;"><i data-lucide="alert-triangle" style="width: 36px; height: 36px;"></i> ĐỪNG ĐỂ "BỆNH NHẸ" TRỞ THÀNH "BỆNH MÃN TÍNH"!</h3>
                    <p style="font-size: 1.1rem; margin-bottom: 16px;">Mỗi tháng trì hoãn có thể là:</p>
                    <ul style="list-style: none; padding: 0; color: var(--text-muted); line-height: 1.8;">
                        <li style="display: flex; align-items: center; gap: 10px;"><div style="width: 6px; height: 6px; background: var(--primary); border-radius: 50%;"></div> Hàng trăm giờ lao động lãng phí</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><div style="width: 6px; height: 6px; background: var(--primary); border-radius: 50%;"></div> Hàng chục triệu đồng chi phí ẩn</li>
                        <li style="display: flex; align-items: center; gap: 10px;"><div style="width: 6px; height: 6px; background: var(--primary); border-radius: 50%;"></div> Những cơ hội tăng trưởng bị bỏ lỡ</li>
                    </ul>
                </div>
                <div style="text-align: center;">
                    <p style="font-size: 1.2rem; font-weight: bold; margin-bottom: 20px;">ĐẶT LỊCH KHÁM BỆNH NHÀ MÁY NGAY HÔM NAY!</p>
                    <button onclick="openContactModal()" class="btn btn-primary" style="font-size: 1.2rem; padding: 16px 40px; box-shadow: 0 4px 20px rgba(249, 115, 22, 0.4);">
                        <i data-lucide="calendar-check"></i> Liên hệ tư vấn
                    </button>
                </div>
            </div>
        </div>
    </section>
"""

# Replace the intro-hero and intro-section with new_content
pattern = r'<div class="intro-hero">.*?</section>'
new_html = re.sub(pattern, new_content.strip(), html, flags=re.DOTALL)

if html != new_html:
    with io.open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_html)
    print("Updated kham-benh-truc-tiep page.")
else:
    print("Could not find pattern to replace.")
