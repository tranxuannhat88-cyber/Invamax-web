import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The HTML to replace
    old_ul = '''<ul style="list-style-type: none; padding-left: 0; margin-bottom: 30px; font-size: 1.1rem;">
                    <li style="margin-bottom: 10px;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; vertical-align: middle; margin-right: 10px;"></i>Khảo sát mô hình vận hành</li>
                    <li style="margin-bottom: 10px;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; vertical-align: middle; margin-right: 10px;"></i>Thiết kế mô hình mục tiêu</li>
                    <li style="margin-bottom: 10px;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; vertical-align: middle; margin-right: 10px;"></i>Đồng hành chuyển đổi tại hiện trường</li>
                </ul>'''
                
    new_ul = '''<ul style="list-style-type: none; padding-left: 0; margin-bottom: 30px; font-size: 1.05rem; display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Tinh gọn bộ máy nhân sự.</li>
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Tăng năng suất lao động.</li>
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Cải thiện chất lượng.</li>
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Thông tin quản trị rõ ràng.</li>
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Vận hành ổn định, ít phụ thuộc vào chủ nhà máy.</li>
                    <li style="display: flex; align-items: flex-start;"><i data-lucide="check-circle" style="color: var(--primary); width: 20px; height: 20px; flex-shrink: 0; margin-right: 10px; margin-top: 3px;"></i>Giảm lãng phí, tăng lợi nhuận.</li>
                </ul>'''

    # Ensure matching even if spacing is slightly different
    import re
    # We will just replace it by finding the start and end of the UL block in the hero text area
    match = re.search(r'<ul style="list-style-type: none; padding-left: 0; margin-bottom: 30px; font-size: 1.1rem;">.*?</ul>', html, re.DOTALL)
    
    if match:
        html = html.replace(match.group(0), new_ul)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old UL in index.html")
except Exception as e:
    print("Error HTML:", e)
