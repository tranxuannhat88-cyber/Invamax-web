import sys

def main():
    try:
        with open('kham-benh-online/assets/js/questions_data.js', 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 1. Fix the ID assignment to use maCau
        for i, line in enumerate(lines):
            if 'id: row[2],' in line:
                lines[i] = line.replace('id: row[2],', 'id: maCau, // Fixed to use maCau as unique ID')
                break

        # 2. Insert new question and bump A05..A11
        # Find A05
        insert_idx = -1
        for i, line in enumerate(lines):
            if '"A05",' in line and 'A - Bối cảnh' in lines[i+1]:
                insert_idx = i - 1
                break
        
        if insert_idx != -1:
            new_q = [
                '  [\n',
                '    "A05",\n',
                '    "A - Bối cảnh",\n',
                '    "FI04b",\n',
                '    "Thông tin nhà máy",\n',
                '    "Nhà máy của anh/chị đã hoạt động được bao nhiêu năm?",\n',
                '    "",\n',
                '    "Điền số",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "",\n',
                '    "0",\n',
                '    "Có",\n',
                '    "Không tính điểm",\n',
                '  ],\n'
            ]
            
            # Bump A05 -> A06 ... A11 -> A12
            for i in range(insert_idx, len(lines)):
                if 'PHẦN B' in lines[i]:
                    break
                for j in range(11, 4, -1):
                    old = f'"A{j:02d}",'
                    new = f'"A{j+1:02d}",'
                    if old in lines[i]:
                        lines[i] = lines[i].replace(old, new)

            lines[insert_idx:insert_idx] = new_q

        with open('kham-benh-online/assets/js/questions_data.js', 'w', encoding='utf-8') as f:
            f.writelines(lines)
        
        print('Updated questions_data.js successfully')
    except Exception as e:
        print('Error:', e)

main()
