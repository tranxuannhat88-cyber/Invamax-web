import io
import re

file_path = 'index.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update cards with card-icon
# We are looking for:
# <div class="card-icon">
#     <i data-lucide="..."></i>
# </div>
# <h3>Title</h3>
# And we want to wrap them in a flex container.

pattern_icon = r'<div class="card-icon">\s*<i data-lucide="([^"]+)"></i>\s*</div>\s*<h3>(.*?)</h3>'

def replacer_icon(match):
    icon_name = match.group(1)
    title = match.group(2)
    return f"""<div style="display: flex; align-items: flex-start; gap: 16px; margin-bottom: 16px;">
                        <div class="card-icon" style="margin-bottom: 0; flex-shrink: 0;">
                            <i data-lucide="{icon_name}"></i>
                        </div>
                        <h3 style="margin-bottom: 0; margin-top: 4px; line-height: 1.4;">{title}</h3>
                    </div>"""

html = re.sub(pattern_icon, replacer_icon, html)


# 2. Update cards with step-number
# We are looking for:
# <div class="step-number" style="...">1</div>
# <h3>Title</h3>

pattern_step = r'<div class="step-number" style="([^"]+)">(\d+)</div>\s*<h3>(.*?)</h3>'

def replacer_step(match):
    style = match.group(1)
    number = match.group(2)
    title = match.group(3)
    
    # Remove margin-bottom from style if it exists
    style = re.sub(r'margin-bottom:\s*\d+px;?', '', style).strip()
    # Add flex-shrink: 0
    if not style.endswith(';'): style += ';'
    style += ' flex-shrink: 0;'
    
    return f"""<div style="display: flex; align-items: flex-start; gap: 16px; margin-bottom: 16px;">
                        <div class="step-number" style="{style}">{number}</div>
                        <h3 style="margin-bottom: 0; margin-top: 4px; line-height: 1.4;">{title}</h3>
                    </div>"""

html = re.sub(pattern_step, replacer_step, html)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated cards to have inline titles.")
