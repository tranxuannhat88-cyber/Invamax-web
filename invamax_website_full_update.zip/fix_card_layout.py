import io

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

old_string = '<div class="intro-grid" style="align-items: stretch; margin-bottom: 60px;">'
new_string = '<div style="display: flex; flex-direction: column; gap: 40px; margin-bottom: 60px;">'

html = html.replace(old_string, new_string)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Fixed card layout.")
