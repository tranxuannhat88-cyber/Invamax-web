import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Update Địa chỉ nhà máy
    old_diachi_label = '<label>Địa chỉ nhà máy</label>'
    new_diachi_label = '<label>Địa chỉ nhà máy *</label>'
    old_diachi_input = '<input type="text" name="diaChi" placeholder="KCN abc, Tỉnh xyz...">'
    new_diachi_input = '<input type="text" name="diaChi" required placeholder="KCN abc, Tỉnh xyz...">'
    
    html = html.replace(old_diachi_label, new_diachi_label)
    html = html.replace(old_diachi_input, new_diachi_input)

    # 2. Update Lĩnh vực sản xuất
    old_linhvuc_label = '<label>Lĩnh vực sản xuất</label>'
    new_linhvuc_label = '<label>Lĩnh vực sản xuất *</label>'
    old_linhvuc_select = '<select name="linhVuc">'
    new_linhvuc_select = '<select name="linhVuc" required>'
    
    html = html.replace(old_linhvuc_label, new_linhvuc_label)
    html = html.replace(old_linhvuc_select, new_linhvuc_select)

    # 3. Update Quy mô nhân sự
    old_quymo_label = '<label>Quy mô nhân sự</label>'
    new_quymo_label = '<label>Quy mô nhân sự *</label>'
    # Since Quy mô nhân sự doesn't have a default empty option, maybe we should add one so required works, 
    # but the user already has it defaulted to 'Dưới 50 người'. A required attribute on a select only checks if value is empty.
    # Since 'Dưới 50 người' is valid, it's fine, but let's add required anyway just for consistency and add * to label.
    old_quymo_select = '<select name="quyMo">'
    new_quymo_select = '<select name="quyMo" required>'
    
    html = html.replace(old_quymo_label, new_quymo_label)
    html = html.replace(old_quymo_select, new_quymo_select)

    with io.open(index_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated index.html")
except Exception as e:
    print("Error HTML:", e)
