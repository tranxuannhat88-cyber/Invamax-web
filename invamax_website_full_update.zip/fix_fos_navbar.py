import io
import re
import os

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'
files = [r'fos-standard\gioi-thieu.html', r'fos-premium\gioi-thieu.html']

correct_navbar = """    <nav class="navbar">
        <div class="container">
            <a href="../index.html" class="logo">INVA<span>MAX</span></a>
            <div class="nav-links">
                <a href="../index.html">Giới thiệu<br>INVAMAX</a>
                <a href="../dich-vu.html#kham-benh">Khám bệnh<br>nhà máy</a>
                <a href="../dich-vu.html#lean" class="active">Tư vấn<br>triển khai Lean</a>
                <a href="../dich-vu.html#so-hoa">Số hoá/AI<br>sản xuất</a>
                <a href="../san-pham.html">INVAMAX<br>Supply Hub</a>
                <a href="../kien-thuc.html">Chia sẻ<br>kiến thức</a>
                <a href="../thu-vien.html">Thư viện<br>tài liệu</a>
            </div>
            <button class="mobile-menu-btn"><i data-lucide="menu"></i></button>
        </div>
    </nav>"""

for file_path in files:
    full_path = os.path.join(base_dir, file_path)
    with io.open(full_path, 'r', encoding='utf-8') as f:
        html = f.read()
    
    # 1. Replace navbar
    navbar_pattern = r'<nav class="navbar">.*?</nav>'
    html = re.sub(navbar_pattern, correct_navbar, html, flags=re.DOTALL)
    
    # 2. Add button below conclusion-box if not already added
    button_html = """
            <div style="text-align: center; margin-top: 40px;">
                <button onclick="openContactModal()" class="btn btn-primary btn-lg" style="padding: 15px 40px; font-size: 1.1rem; border-radius: 8px;">Liên hệ tư vấn</button>
            </div>"""
            
    if 'Liên hệ tư vấn' not in html[html.find('conclusion-box'):]:
        conclusion_pattern = r'(<div class="conclusion-box">.*?</div>)'
        html = re.sub(conclusion_pattern, r'\1' + button_html, html, flags=re.DOTALL)
    
    with io.open(full_path, 'w', encoding='utf-8') as f:
        f.write(html)

print("Fixed navbar and added bottom CTA button.")
