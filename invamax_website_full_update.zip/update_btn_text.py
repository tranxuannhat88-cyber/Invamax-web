import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The text to replace
    old_text = "Liên hệ để đánh giá nhà máy của bạn"
    new_text = "Liên hệ để được tư vấn"
    
    if old_text in html:
        html = html.replace(old_text, new_text)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old text in index.html")
except Exception as e:
    print("Error HTML:", e)
