import io
import os
import re

# 1. Update HTML files to add stretched-link
html_dir = '.'
for root, dirs, files in os.walk(html_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            original_html = html
            # Replace class="btn btn-outline" with class="btn btn-outline stretched-link" for links containing "Xem chi tiết"
            html = re.sub(r'(class="btn btn-outline"[^>]*>Xem chi tiết</a>)', r'class="btn btn-outline stretched-link" style="\g<1>', html)
            # Wait, the regex is a bit risky. Let's just do simple replace since it's exactly the same in dich-vu.html.
            
            html = html.replace('class="btn btn-outline" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>', 'class="btn btn-outline stretched-link" style="text-align: center; padding: 10px 0;">Xem chi tiết</a>')
            
            if html != original_html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(html)
                print(f"Added stretched-link to {file_path}")

# 2. Update style.css
css_path = r'assets\css\style.css'
with io.open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Make sure .card has position: relative
if "position: relative;" not in css_content.split('.card {')[1].split('}')[0]:
    css_content = css_content.replace('.card {\n', '.card {\n    position: relative;\n')
    print("Added position: relative to .card")

# Add stretched-link css
stretched_css = """
/* Make the whole card clickable via the Xem chi tiet link */
.stretched-link::after {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1;
    content: "";
}
/* Ensure the primary button is above the stretched link so it can still be clicked */
.card .btn-primary, .intro-card .btn-primary {
    position: relative;
    z-index: 2;
}
"""

if ".stretched-link::after" not in css_content:
    css_content += stretched_css
    with io.open(css_path, 'w', encoding='utf-8') as f:
        f.write(css_content)
    print("Added stretched-link CSS")
