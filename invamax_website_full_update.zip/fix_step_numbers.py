import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The inline style to remove
    bad_style = ' style="font-size: 1.5rem; color: var(--primary); font-weight: 900; margin-bottom: 10px;"'
    
    # Replace it across all step-numbers (01 to 06)
    if bad_style in html:
        html = html.replace(bad_style, '')
        
        # also we need to make sure shrink is prevented so the circle doesn't get squeezed
        # Actually in style.css, flex-shrink is default. Let's add flex-shrink: 0 to style.css just in case
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the bad style in index.html")
except Exception as e:
    print("Error HTML:", e)

style_css = r"assets\css\style.css"
try:
    with io.open(style_css, 'r', encoding='utf-8') as f:
        css = f.read()
    
    if "flex-shrink: 0;" not in css.split(".step-number {")[1].split("}")[0]:
        css = css.replace('.step-number {\n    width: 48px;\n    height: 48px;', '.step-number {\n    width: 48px;\n    height: 48px;\n    flex-shrink: 0;')
        with io.open(style_css, 'w', encoding='utf-8') as f:
            f.write(css)
        print("Updated style.css")
except Exception as e:
    pass
