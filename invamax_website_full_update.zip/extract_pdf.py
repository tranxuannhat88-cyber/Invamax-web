import fitz
import os

pdf_path = r"C:\Users\MAY TINH 2K\.gemini\antigravity\brain\9623add7-f2ce-4d39-a9c2-80f4e607da26\.user_uploaded\media__1785142219543.pdf"
output_dir = r"assets\images"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

doc = fitz.open(pdf_path)

pages_to_extract = {
    0: "report_dashboard.png",
    2: "report_wastes.png",
    13: "report_matrix.png",
    17: "report_roadmap.png"
}

for page_num, filename in pages_to_extract.items():
    if page_num < len(doc):
        page = doc[page_num]
        pix = page.get_pixmap(dpi=150) # Good quality for web
        output_path = os.path.join(output_dir, filename)
        pix.save(output_path)
        print(f"Saved {filename}")
    else:
        print(f"Page {page_num} out of range")

doc.close()
