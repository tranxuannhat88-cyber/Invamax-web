import io
import re

file_path = r'kham-benh-online\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

images_html = """
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
                                <img src="../assets/images/report_dashboard.png" alt="Báo cáo Dashboard" style="width: 100%; border-radius: 4px; border: 1px solid #e5e7eb; cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <img src="../assets/images/report_wastes.png" alt="Bản đồ 8 lãng phí" style="width: 100%; border-radius: 4px; border: 1px solid #e5e7eb; cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <img src="../assets/images/report_matrix.png" alt="Ma trận ưu tiên" style="width: 100%; border-radius: 4px; border: 1px solid #e5e7eb; cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <img src="../assets/images/report_roadmap.png" alt="Lộ trình 30-60-90" style="width: 100%; border-radius: 4px; border: 1px solid #e5e7eb; cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                            </div>
"""

placeholder = """
                            <!-- Placeholder cho ảnh minh họa báo cáo -->
                            <div style="width: 100%; height: 280px; background-color: #f3f4f6; border-radius: 4px; border: 1px solid #e5e7eb; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #6b7280; font-size: 0.95rem;">
                                <i data-lucide="image" style="width: 48px; height: 48px; margin-bottom: 12px; opacity: 0.5;"></i>
                                Hình ảnh minh hoạ báo cáo
                            </div>
"""

if "Hình ảnh minh hoạ báo cáo" in html:
    new_html = html.replace(placeholder.strip(), images_html.strip())
    with io.open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_html)
    print("Replaced placeholder with images.")
else:
    print("Placeholder not found.")
