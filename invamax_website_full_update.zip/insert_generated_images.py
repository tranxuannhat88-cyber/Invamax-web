import io
import re

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# I will replace the first card
card1_start = r'<div class="intro-card" style="margin-bottom: 0;">\s*<h3 style="text-transform: uppercase;">Khám bệnh nhà máy cùng INVAMAX</h3>'
card1_end = r'</ul>\s*</div>'

def replacer1(match):
    content = match.group(0)
    # Extract inner content
    inner = content.replace('<div class="intro-card" style="margin-bottom: 0;">', '')
    inner = inner.rsplit('</div>', 1)[0]
    
    return f"""<div class="intro-card" style="margin-bottom: 0; display: flex; align-items: center; gap: 40px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 300px;">
                        {inner.strip()}
                    </div>
                    <div style="flex: 1; min-width: 300px; text-align: center;">
                        <img src="../assets/images/expert_inspection.jpg" alt="Chuyên gia INVAMAX khảo sát thực tế" style="width: 100%; max-width: 400px; border-radius: 12px; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5);">
                    </div>
                </div>"""

# Find and replace card1 using DOTALL
# Wait, let's just do simple replace since I know the exact structure
pattern1 = r'<div class="intro-card" style="margin-bottom: 0;">\s*<h3 style="text-transform: uppercase;">Khám bệnh nhà máy cùng INVAMAX</h3>.*?</ul>\s*</div>'
html = re.sub(pattern1, replacer1, html, flags=re.DOTALL)

# For the second card
pattern2 = r'<div class="intro-card" style="margin-bottom: 0; background-color: rgba\(255,255,255,0\.02\);">\s*<h3 style="text-transform: uppercase; color: var\(--text-white\);">.*?</div>\s*</div>\s*</div>'

def replacer2(match):
    content = match.group(0)
    # Extract inner content
    inner = content.replace('<div class="intro-card" style="margin-bottom: 0; background-color: rgba(255,255,255,0.02);">', '')
    inner = inner.rsplit('</div>', 1)[0]
    
    return f"""<div class="intro-card" style="margin-bottom: 0; background-color: rgba(255,255,255,0.02); display: flex; align-items: center; gap: 40px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 300px;">
                        {inner.strip()}
                    </div>
                    <div style="flex: 1; min-width: 300px; text-align: center;">
                        <img src="../assets/images/factory_report.jpg" alt="Báo cáo hiện trạng nhà máy" style="width: 100%; max-width: 400px; border-radius: 12px; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5);">
                    </div>
                </div>"""

html = re.sub(pattern2, replacer2, html, flags=re.DOTALL)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("Updated html with images.")
