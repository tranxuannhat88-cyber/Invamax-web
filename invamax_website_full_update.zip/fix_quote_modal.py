import io

html_path = r"san-pham.html"

with io.open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Fix 1: The close button
old_close = '<button class="modal-close" onclick="closeQuoteModal()"><i data-lucide="x"></i></button>'
new_close = '<button class="modal-close" onclick="closeQuoteModal()" style="font-size: 24px; line-height: 1; font-weight: bold; color: #64748b; background: none; border: none; cursor: pointer;">&times;</button>'
html = html.replace(old_close, new_close)

# Fix 2: The title
old_h2 = '<h2>Yêu cầu báo giá</h2>'
new_h2 = '<h2 style="font-size: 1.5rem; color: var(--primary); margin-bottom: 5px;">Gửi đề nghị báo giá</h2>'
html = html.replace(old_h2, new_h2)

# Fix 3: The subtitle <p>
old_p = '<p>Vui lòng để lại thông tin, chuyên gia của chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.</p>'
new_p = '<p style="color: #64748b; margin-bottom: 20px; font-size: 0.95rem;">Vui lòng để lại thông tin, chuyên gia của chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.</p>'
html = html.replace(old_p, new_p)

# Just in case they had <div class="modal-header"> wrapping them
# It's already replaced individually.

with io.open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)
print("Fixed modal styling in san-pham.html")
