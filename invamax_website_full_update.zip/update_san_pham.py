import io
import re

html_path = r"san-pham.html"

with io.open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Remove the Bàn thao tác top section
# It starts at <div class="grid-2" style="align-items: center; margin-bottom: 80px;">
# and ends at the </div> before <h2 class="section-title text-center mb-5">Hệ sinh thái sản phẩm Supply Hub</h2>
top_section_start = html.find('<div class="grid-2" style="align-items: center; margin-bottom: 80px;">')
top_section_end = html.find('<h2 class="section-title text-center mb-5">Hệ sinh thái sản phẩm Supply Hub</h2>')

if top_section_start != -1 and top_section_end != -1:
    # Get everything up to top_section_start, and from top_section_end
    html = html[:top_section_start] + html[top_section_end:]

# 2. Find <div class="grid-3"> and replace it with a 4-column auto-fit grid
grid_start = html.find('<div class="grid-3">')
if grid_start != -1:
    new_grid_div = '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin-bottom: 50px;">'
    html = html[:grid_start] + new_grid_div + html[grid_start + len('<div class="grid-3">'):]
    
# 3. Add the Bàn thao tác card as the first card
# The first card was Linh kiện. I will find <!-- Product 1 --> and insert before it.
p1_start = html.find('<!-- Product 1 -->')
if p1_start != -1:
    ban_thao_tac_card = '''
                <!-- Bàn thao tác -->
                <div class="card" style="display: flex; flex-direction: column;">
                    <div class="card-icon"><i data-lucide="monitor"></i></div>
                    <h3>Bàn thao tác chuyên dụng</h3>
                    <p style="margin-bottom: 16px;">Bàn lắp ráp, bàn đóng gói, bàn kiểm tra được thiết kế tối ưu công thái học, giảm tối đa thao tác thừa. Thiết kế may đo dựa trên thực tế tại hiện trường.</p>
                    <div style="margin-top: auto; border-radius: 8px; overflow: hidden; aspect-ratio: 4/3;">
                        <img src="assets/images/ergonomic_assembly_table_1783944885974.jpg" alt="Bàn thao tác" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                </div>
                '''
    html = html[:p1_start] + ban_thao_tac_card + html[p1_start:]

# 4. Add the Big Button below the grid. The grid ends before </section> (Wait, it ends before "<!-- Footer Included Here -->").
# Let's find the closing tag of the grid. We can find '<!-- Product 3 -->\n                <div class="card">\n                    <div class="card-icon"><i data-lucide="wrench"></i></div>\n                    <h3>Thiết bị, dụng cụ sản xuất</h3>\n                    <p>Thiết bị tự động, bán tự động. Đồ gá, dưỡng, dụng cụ hỗ trợ sản xuất được chế tạo bởi hệ sinh thái đối tác cơ khí chính xác.</p>\n                </div>\n            </div>'
p3_str = '''<!-- Product 3 -->
                <div class="card">
                    <div class="card-icon"><i data-lucide="wrench"></i></div>
                    <h3>Thiết bị, dụng cụ sản xuất</h3>
                    <p>Thiết bị tự động, bán tự động. Đồ gá, dưỡng, dụng cụ hỗ trợ sản xuất được chế tạo bởi hệ sinh thái đối tác cơ khí chính xác.</p>
                </div>
            </div>'''
            
if p3_str in html:
    big_btn_html = '''
            <!-- Big Button -->
            <div style="text-align: center; margin-top: 20px;">
                <button onclick="openQuoteModal()" class="btn btn-primary" style="font-size: 1.2rem; padding: 16px 60px; border-radius: 99px; box-shadow: 0 4px 20px rgba(249, 115, 22, 0.4);">
                    <i data-lucide="file-text" style="width: 24px; height: 24px; margin-right: 8px; vertical-align: middle;"></i> Nhận báo giá
                </button>
            </div>
            '''
    html = html.replace(p3_str, p3_str + big_btn_html)

# 5. Add Modal HTML and script tag at the end of body
modal_html = '''
    <!-- Quote Modal -->
    <div id="quoteModal" class="modal-overlay">
        <div class="modal-content" style="max-width: 600px;">
            <button class="modal-close" onclick="closeQuoteModal()"><i data-lucide="x"></i></button>
            <div class="modal-header">
                <h2>Yêu cầu báo giá</h2>
                <p>Vui lòng để lại thông tin, chuyên gia của chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.</p>
            </div>
            <form id="quoteForm" onsubmit="submitQuoteForm(event)">
                <div class="form-group">
                    <label>Họ và tên *</label>
                    <input type="text" class="form-control" name="name" required placeholder="Nhập họ và tên của bạn">
                </div>
                <div class="form-group">
                    <label>Tên công ty/Nhà máy *</label>
                    <input type="text" class="form-control" name="company" required placeholder="Nhập tên công ty">
                </div>
                <div class="form-group" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <label>Số điện thoại *</label>
                        <input type="tel" class="form-control" name="phone" required placeholder="Số điện thoại liên hệ">
                    </div>
                    <div>
                        <label>Email *</label>
                        <input type="email" class="form-control" name="email" required placeholder="Email liên hệ">
                    </div>
                </div>
                <div class="form-group">
                    <label>Sản phẩm/Dịch vụ quan tâm *</label>
                    <textarea class="form-control" name="requirement" rows="4" required placeholder="Mô tả chi tiết yêu cầu, số lượng, kích thước..."></textarea>
                </div>
                <div class="form-group">
                    <label>Đính kèm hình ảnh/file đính kèm (Tùy chọn)</label>
                    <input type="file" id="quoteFile" class="form-control" name="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" style="padding: 10px;">
                    <small style="color: var(--text-muted); display: block; margin-top: 5px;">Hỗ trợ: JPG, PNG, PDF, DOC, XLS (Tối đa 5MB)</small>
                </div>
                <button type="submit" id="btnSubmitQuote" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                    Gửi yêu cầu báo giá
                </button>
                <div id="quoteLoading" style="display: none; text-align: center; margin-top: 15px; color: var(--primary);">
                    <i data-lucide="loader-2" class="spin"></i> Đang xử lý...
                </div>
                <div id="quoteSuccess" style="display: none; text-align: center; margin-top: 15px; color: #16a34a;">
                    <i data-lucide="check-circle" style="vertical-align: middle;"></i> Gửi yêu cầu thành công!
                </div>
            </form>
        </div>
    </div>
'''

if 'id="quoteModal"' not in html:
    body_end = html.find('</body>')
    if body_end != -1:
        # insert modal and quote.js
        scripts = '<script src="assets/js/quote.js"></script>\n'
        html = html[:body_end] + modal_html + scripts + html[body_end:]

with io.open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated san-pham.html")
