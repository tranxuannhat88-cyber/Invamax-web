import io

quote_js_path = r"assets\js\quote.js"
main_js_path = r"assets\js\main.js"
url = "https://script.google.com/macros/s/AKfycbwINtrEt8nfP0lzCeTKAbmCgUzsgGs_EkGdmEKjQQfxKubCoIAnhivJK0mNnuHFd4Ds/exec"

# Update quote.js
try:
    with io.open(quote_js_path, 'r', encoding='utf-8') as f:
        quote_content = f.read()
    
    quote_content = quote_content.replace("'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE'", f"'{url}'")
    
    with io.open(quote_js_path, 'w', encoding='utf-8') as f:
        f.write(quote_content)
    print("Updated quote.js")
except Exception as e:
    print(f"Error updating quote.js: {e}")

# Update main.js
try:
    with io.open(main_js_path, 'r', encoding='utf-8') as f:
        main_content = f.read()
    
    main_content = main_content.replace('"YOUR_WEB_APP_URL_HERE"', f'"{url}"')
    
    with io.open(main_js_path, 'w', encoding='utf-8') as f:
        f.write(main_content)
    print("Updated main.js")
except Exception as e:
    print(f"Error updating main.js: {e}")
