import io
import re
import os

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

# 1. Read the full contact modal from index.html
with io.open(os.path.join(base_dir, 'index.html'), 'r', encoding='utf-8') as f:
    index_html = f.read()

# Extract the modal block
modal_pattern = r'(<!-- Contact Modal -->\s*<div id="contactModal".*?</div>\s*</div>\s*</div>)'
match = re.search(modal_pattern, index_html, flags=re.DOTALL)
if match:
    full_modal = match.group(1)
    
    files = [r'fos-standard\gioi-thieu.html', r'fos-premium\gioi-thieu.html']
    
    for file_path in files:
        full_path = os.path.join(base_dir, file_path)
        with io.open(full_path, 'r', encoding='utf-8') as f:
            html = f.read()
        
        # In FOS pages, replace the existing contact modal (which might have <script> tags after it)
        # We replace from <!-- Contact Modal --> to the end of the <div id="contactModal"> block.
        # Actually my previous python script appended a <script> block for open/close modal. 
        # I should replace everything from <!-- Contact Modal --> to before </body>
        
        replace_pattern = r'<!-- Contact Modal -->.*?(?=</body>)'
        
        # We need to preserve the <script> block that handles openContactModal if it's not in main.js, 
        # but actually, index.html has openContactModal() inside main.js? 
        # Wait, if main.js has it, we don't need inline script.
        
        new_html = re.sub(replace_pattern, full_modal + '\n\n', html, flags=re.DOTALL)
        
        if new_html != html:
            with io.open(full_path, 'w', encoding='utf-8') as f:
                f.write(new_html)

    print("Replaced contact modal in FOS pages with the full one from index.html.")
else:
    print("Could not find contact modal in index.html")
