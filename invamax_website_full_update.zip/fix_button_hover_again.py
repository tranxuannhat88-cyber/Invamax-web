import io

css_path = r'assets\css\style.css'
with io.open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Replace the previous hover_button_css with the correct behavior
old_css_part = """/* Synchronized neutral state for buttons inside cards */
.card .btn-outline, .intro-card .btn-outline {
    border-color: rgba(255, 255, 255, 0.2);
    color: #a0aec0;
    transition: all 0.3s ease;
}
.card .btn-primary, .intro-card .btn-primary {
    background-color: rgba(255, 255, 255, 0.1);
    color: #e2e8f0;
    transition: all 0.3s ease;
}

/* Hover state for buttons inside cards */
.card:hover .btn-outline, .intro-card:hover .btn-outline {
    border-color: var(--primary);
    color: var(--primary);
}
.card:hover .btn-outline:hover, .intro-card:hover .btn-outline:hover {
    background-color: var(--primary);
    color: var(--text-white);
}

.card:hover .btn-primary, .intro-card:hover .btn-primary {
    background-color: var(--primary);
    color: var(--text-white);
}
.card:hover .btn-primary:hover, .intro-card:hover .btn-primary:hover {
    background-color: var(--primary-hover);
}"""

new_css_part = """/* Synchronized neutral state for buttons inside cards */
.card .btn-outline, .intro-card .btn-outline, 
.card .btn-primary, .intro-card .btn-primary {
    background-color: transparent;
    border: 2px solid rgba(255, 255, 255, 0.2);
    color: #a0aec0;
    transition: all 0.3s ease;
}

/* Hover state for buttons inside cards - When Card is hovered */
.card:hover .btn-outline, .intro-card:hover .btn-outline,
.card:hover .btn-primary, .intro-card:hover .btn-primary {
    border-color: var(--primary);
    color: var(--primary);
    background-color: transparent;
}

/* Hover state for buttons inside cards - When Button itself is hovered */
.card:hover .btn-outline:hover, .intro-card:hover .btn-outline:hover,
.card:hover .btn-primary:hover, .intro-card:hover .btn-primary:hover,
.card .btn-outline:hover, .intro-card .btn-outline:hover,
.card .btn-primary:hover, .intro-card .btn-primary:hover {
    background-color: var(--primary);
    color: var(--text-white);
    border-color: var(--primary);
}"""

if old_css_part in css_content:
    css_content = css_content.replace(old_css_part, new_css_part)
    with io.open(css_path, 'w', encoding='utf-8') as f:
        f.write(css_content)
    print("Fixed button hover styles in style.css")
else:
    print("Could not find old css part")
