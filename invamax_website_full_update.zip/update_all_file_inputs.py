import io
import re
import os

root_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

target = r'<input type="file" id="quoteFile" class="form-control" name="file" accept="image/\*,\.pdf,\.doc,\.docx,\.xls,\.xlsx" style="padding: 10px;">\s*<small style="color: var\(--text-muted\); display: block; margin-top: 5px;">Hỗ trợ: JPG, PNG, PDF, DOC, XLS \(Tối đa 5MB\)</small>'

replacement = """<input type="file" id="quoteFile" class="form-control" name="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" style="padding: 10px;" multiple onchange="if(this.files.length > 2) { alert('Bạn chỉ được chọn tối đa 2 file đính kèm.'); this.value = ''; }">
                    <small style="color: var(--text-muted); display: block; margin-top: 5px;">Hỗ trợ: JPG, PNG, PDF, DOC, XLS (Tối đa 5MB/file - Chọn tối đa 2 file)</small>"""

count = 0
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            new_html = re.sub(target, replacement, html)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Updated {count} html files.")
