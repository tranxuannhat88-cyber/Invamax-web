import io
import re

file_path = r'kham-benh-online\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Find the old grid and replace it
old_grid_pattern = r'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">.*?</div>'

new_grid = """
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 20px;">
                                <div style="border-radius: 8px; overflow: hidden; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);">
                                    <img src="../assets/images/report_dashboard.png" alt="Báo cáo Dashboard" style="width: 100%; display: block; transition: transform 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
                                </div>
                                <div style="border-radius: 8px; overflow: hidden; box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);">
                                    <img src="../assets/images/report_wastes.png" alt="Bản đồ 8 lãng phí" style="width: 100%; display: block; transition: transform 0.3s ease; cursor: pointer;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
                                </div>
                            </div>
"""

# Try to replace
new_html = re.sub(old_grid_pattern, new_grid.strip(), html, flags=re.DOTALL)

if html != new_html:
    with io.open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_html)
    print("Updated images to 2 images neatly.")
else:
    print("Could not find old grid.")
