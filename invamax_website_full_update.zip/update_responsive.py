import io
import re

style_css = r"assets\css\style.css"

try:
    with io.open(style_css, 'r', encoding='utf-8') as f:
        css = f.read()

    # 1. Update container max-width from 1200px to 1440px
    css = css.replace('max-width: 1200px;', 'max-width: 1440px;')

    # 2. Add mobile optimizations for hero buttons and title
    if ".hero-buttons-mobile" not in css:
        mobile_css = '''
/* Additional Mobile Optimizations */
@media (max-width: 768px) {
    .hero-main-title {
        font-size: 2.2rem !important;
        margin-bottom: 25px !important;
        text-align: center;
    }
    .hero-buttons {
        flex-direction: column;
        width: 100%;
    }
    .hero-buttons .btn {
        width: 100%;
        margin-bottom: 10px;
    }
    .hero-content {
        gap: 40px;
    }
}
'''
        # Just append it to the end
        css += mobile_css
    
    with io.open(style_css, 'w', encoding='utf-8') as f:
        f.write(css)
    print("Updated style.css")
except Exception as e:
    print("Error CSS:", e)
