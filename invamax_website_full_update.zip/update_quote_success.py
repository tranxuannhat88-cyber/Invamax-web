import io
import re

html_path = r"san-pham.html"

with io.open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Replace the end of the form block
old_form_end = """                <div id="quoteLoading" style="display: none; text-align: center; margin-top: 15px; color: var(--primary);">
                    <i data-lucide="loader-2" class="spin"></i> Đang xử lý...
                </div>
                <div id="quoteSuccess" style="display: none; text-align: center; margin-top: 15px; color: #16a34a;">
                    <i data-lucide="check-circle" style="vertical-align: middle;"></i> Gửi yêu cầu thành công!
                </div>
            </form>
        </div>
    </div>"""

new_form_end = """                <div id="quoteLoading" style="display: none; text-align: center; margin-top: 15px; color: var(--primary);">
                    <i data-lucide="loader-2" class="spin"></i> Đang xử lý...
                </div>
            </form>

            <div id="quoteSuccess" style="display: none; text-align: center; padding: 30px 0;">
                <i data-lucide="check-circle" style="color: #22c55e; width: 64px; height: 64px; margin-bottom: 15px; margin: 0 auto; display: block;"></i>
                <h3 style="color: #16a34a; font-size: 1.3rem; margin-top: 15px;">Gửi thành công!</h3>
                <p style="color: #475569; margin-top: 10px;">Cảm ơn bạn. Chuyên gia INVAMAX sẽ phân tích và gửi báo giá sớm nhất.</p>
                <button type="button" class="btn btn-outline" style="margin-top: 20px;" onclick="closeQuoteModal()">Đóng cửa sổ</button>
            </div>
        </div>
    </div>"""

if old_form_end in html:
    html = html.replace(old_form_end, new_form_end)
    with io.open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated san-pham.html")
else:
    print("Could not find the target string in san-pham.html")


js_path = r"assets\js\quote.js"
with io.open(js_path, 'r', encoding='utf-8') as f:
    js_content = f.read()

# Update the logic when success occurs in submitQuoteForm
old_js_success = """        if (result.status === 'success') {
            loading.style.display = 'none';
            successMsg.style.display = 'block';
            setTimeout(closeQuoteModal, 3000);
        }"""
new_js_success = """        if (result.status === 'success') {
            loading.style.display = 'none';
            document.getElementById('quoteForm').style.display = 'none';
            document.getElementById('quoteSuccess').style.display = 'block';
            lucide.createIcons();
        }"""

# Update closeQuoteModal to reset the form visibility
old_js_close = """function closeQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.remove('active');
    }
}"""
new_js_close = """function closeQuoteModal() {
    const modal = document.getElementById('quoteModal');
    if (modal) {
        modal.classList.remove('active');
        // Reset form visibility for next time
        const form = document.getElementById('quoteForm');
        const success = document.getElementById('quoteSuccess');
        if (form && success) {
            form.style.display = 'block';
            success.style.display = 'none';
            form.reset();
        }
    }
}"""

if old_js_success in js_content and old_js_close in js_content:
    js_content = js_content.replace(old_js_success, new_js_success)
    js_content = js_content.replace(old_js_close, new_js_close)
    with io.open(js_path, 'w', encoding='utf-8') as f:
        f.write(js_content)
    print("Updated quote.js")
else:
    print("Could not find target strings in quote.js")
