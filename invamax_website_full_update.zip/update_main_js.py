import io
import re

js_path = r"assets\js\main.js"

with io.open(js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace the submitForm function
old_submit_func_start = "async function submitForm(e) {"
# It ends right before "function closeContactModal" or end of file. Wait, in main.js, closeContactModal was defined BEFORE submitForm.
# Let's use regex to grab everything from async function submitForm(e) { to the end of the block.
# We know the block ends with lucide.createIcons();\n    }\n}

pattern = r"async function submitForm\(e\) \{[\s\S]*?lucide\.createIcons\(\);\n\s*\}\n\}"
match = re.search(pattern, content)

new_submit_func = """async function submitForm(e) {
    e.preventDefault();
    if(GOOGLE_SCRIPT_URL === "YOUR_WEB_APP_URL_HERE") {
        alert("Tính năng đang được thiết lập (Thiếu URL Webhook).");
        return;
    }
    
    const form = document.getElementById('leadForm');
    const btn = document.getElementById('btnSubmitForm');
    const formData = new FormData(form);
    
    let data = { formType: 'contact' };
    formData.forEach((value, key) => data[key] = value);
    
    btn.innerHTML = 'Đang gửi...';
    btn.disabled = true;
    
    try {
        const response = await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'text/plain;charset=utf-8'
            }
        });
        
        const result = await response.json();
        if (result.status === 'success') {
            document.getElementById('leadForm').style.display = 'none';
            document.getElementById('formSuccess').style.display = 'block';
        } else {
            throw new Error(result.message || "Lỗi không xác định");
        }
    } catch(err) {
        alert("Có lỗi xảy ra khi gửi dữ liệu. Vui lòng thử lại sau.");
        console.error(err);
    } finally {
        btn.innerHTML = '<i data-lucide="send"></i> Gửi Đề Nghị';
        btn.disabled = false;
        lucide.createIcons();
    }
}"""

if match:
    content = content.replace(match.group(0), new_submit_func)
    with io.open(js_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Updated main.js successfully")
else:
    print("Could not find submitForm in main.js")
