import io
import re

file_path = r'kham-benh-truc-tiep\gioi-thieu.html'

with io.open(file_path, 'r', encoding='utf-8') as f:
    html = f.read()

# Pattern for Card 1
card1_pattern = r'<div class="intro-card" style="margin-bottom: 0; display: flex; align-items: center; gap: 20px;">\s*<div style="flex: 1;">(.*?)</div>\s*<div style="width: 140px; flex-shrink: 0;">\s*<img src="\.\./assets/images/expert_inspection\.jpg".*?</div>\s*</div>'

def replacer1(match):
    text_content = match.group(1).strip()
    return f"""<div class="intro-card" style="margin-bottom: 0;">
                    {text_content}
                </div>"""

html = re.sub(card1_pattern, replacer1, html, flags=re.DOTALL)

# Pattern for Card 2
card2_pattern = r'<div class="intro-card" style="margin-bottom: 0; background-color: rgba\(255,255,255,0\.02\); display: flex; align-items: center; gap: 20px;">\s*<div style="flex: 1;">(.*?)</div>\s*<div style="width: 140px; flex-shrink: 0;">\s*<img src="\.\./assets/images/factory_report\.jpg".*?</div>\s*</div>'

def replacer2(match):
    text_content = match.group(1).strip()
    return f"""<div class="intro-card" style="margin-bottom: 0; background-color: rgba(255,255,255,0.02);">
                    {text_content}
                </div>"""

html = re.sub(card2_pattern, replacer2, html, flags=re.DOTALL)

with io.open(file_path, 'w', encoding='utf-8') as f:
    f.write(html)
    
print("Reverted images.")
