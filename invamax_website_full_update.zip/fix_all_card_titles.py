import io
import re
import os

root_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

# We look for card-icon followed by an h3 tag.
pattern_icon = r'<div class="card-icon">\s*<i data-lucide="([^"]+)"></i>\s*</div>\s*<h3([^>]*)>(.*?)</h3>'

def replacer_icon(match):
    icon_name = match.group(1)
    h3_attrs = match.group(2)
    title = match.group(3)
    
    # We need to extract any existing styles from the h3 tag if present, but usually they are just plain <h3>
    # We will inject our flex styles into the wrapper and adjust the h3.
    # To be safe, we just keep h3_attrs and append our style inline, or if style already exists, this might be tricky.
    # Let's assume there are no conflicting inline styles on h3 for layout, we just add margin-bottom: 0; margin-top: 4px; line-height: 1.4;
    
    if 'style="' in h3_attrs:
        h3_attrs = h3_attrs.replace('style="', 'style="margin-bottom: 0; margin-top: 4px; line-height: 1.4; ')
    else:
        h3_attrs += ' style="margin-bottom: 0; margin-top: 4px; line-height: 1.4;"'
        
    return f"""<div style="display: flex; align-items: flex-start; gap: 16px; margin-bottom: 16px;">
                        <div class="card-icon" style="margin-bottom: 0; flex-shrink: 0;">
                            <i data-lucide="{icon_name}"></i>
                        </div>
                        <h3{h3_attrs}>{title}</h3>
                    </div>"""

count = 0
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            new_html = re.sub(pattern_icon, replacer_icon, html)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Updated card titles globally in {count} html files.")
