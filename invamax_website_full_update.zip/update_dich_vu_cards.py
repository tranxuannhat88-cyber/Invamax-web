import io
import re

index_html = r"index.html"
dich_vu_html = r"dich-vu.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        idx_html = f.read()

    # Extract the modal block from index.html
    modal_start = idx_html.find('<!-- Contact Modal -->')
    modal_end = idx_html.find('</body>')
    # Actually, the modal goes until just before <script src="assets/js/main.js"></script>
    script_start = idx_html.find('<script src="assets/js/main.js"></script>')
    if modal_start != -1 and script_start != -1:
        modal_html = idx_html[modal_start:script_start].strip() + "\n\n"
    else:
        print("Could not find modal block in index.html")
        modal_html = ""

    with io.open(dich_vu_html, 'r', encoding='utf-8') as f:
        dv_html = f.read()

    # 1. Rename card title
    dv_html = dv_html.replace('Khám bệnh nhà máy 3 ngày', 'Khám bệnh trực tiếp tại nhà máy')

    # 2. Update button text and action
    # We have: <a href="mailto:nhattran.invamax@gmail.com" class="btn btn-outline" style="width: 100%; text-align: center;">Liên hệ tư vấn</a>
    old_btn = '<a href="mailto:nhattran.invamax@gmail.com" class="btn btn-outline" style="width: 100%; text-align: center;">Liên hệ tư vấn</a>'
    new_btn = '<button onclick="openContactModal()" class="btn btn-outline" style="width: 100%; text-align: center; display: block; border-radius: 99px;">Liên hệ để được tư vấn</button>'
    
    dv_html = dv_html.replace(old_btn, new_btn)

    # 3. Center the grid and make cards equal size
    # We changed grid-3 to grid-2 earlier. Let's find it.
    old_grid = '<div class="grid-2">'
    new_grid = '<div class="grid-2" style="max-width: 900px; margin: 0 auto; align-items: stretch;">'
    # Actually wait, align-items stretch is default for flex and grid. 
    # But one card has `transform: scale(1.05);` which makes it larger. Let's remove that.
    
    dv_html = dv_html.replace(old_grid, new_grid)
    
    # Remove `transform: scale(1.05); box-shadow: 0 10px 30px rgba(0,0,0,0.2); z-index: 1;` from the second card
    card_style_old = 'style="border-top: 4px solid var(--primary); transform: scale(1.05); box-shadow: 0 10px 30px rgba(0,0,0,0.2); z-index: 1;"'
    card_style_new = 'style="border-top: 4px solid var(--primary);"'
    dv_html = dv_html.replace(card_style_old, card_style_new)

    # 4. Inject modal if not present
    if 'id="contactModal"' not in dv_html and modal_html:
        dv_script_start = dv_html.find('<script src="assets/js/main.js"></script>')
        if dv_script_start != -1:
            dv_html = dv_html[:dv_script_start] + modal_html + dv_html[dv_script_start:]

    with io.open(dich_vu_html, 'w', encoding='utf-8') as f:
        f.write(dv_html)
    print("Updated dich-vu.html")

except Exception as e:
    print("Error:", e)
