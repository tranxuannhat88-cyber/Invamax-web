import io
import os
import re

base_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'
files = [r'fos-standard\gioi-thieu.html', r'fos-premium\gioi-thieu.html']

pattern = r'<button onclick="openContactModal\(\)" class="btn btn-primary btn-lg">Nhận tư vấn & Báo giá</button>'

for file_path in files:
    full_path = os.path.join(base_dir, file_path)
    with io.open(full_path, 'r', encoding='utf-8') as f:
        html = f.read()
        
    new_html = re.sub(pattern, '', html)
    
    if new_html != html:
        with io.open(full_path, 'w', encoding='utf-8') as f:
            f.write(new_html)

print("Removed the button from hero section.")
