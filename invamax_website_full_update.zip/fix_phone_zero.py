import io

js_path = r"backend\google_apps_script.js"

with io.open(js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace data.phone with (data.phone ? "'" + data.phone : "") in the appendRow array
content = content.replace("            data.phone,", "            data.phone ? \"'\" + data.phone : \"\",")

# Replace data.soDienThoai with (data.soDienThoai ? "'" + data.soDienThoai : "") in the appendRow array
content = content.replace("            data.soDienThoai,", "            data.soDienThoai ? \"'\" + data.soDienThoai : \"\",")

with io.open(js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated google_apps_script.js to fix phone number leading zero")
