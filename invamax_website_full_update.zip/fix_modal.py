import io
import re

style_css = r"assets\css\style.css"
index_html = r"index.html"

# 1. Update style.css
try:
    with io.open(style_css, 'r', encoding='utf-8') as f:
        css = f.read()

    old_modal_overlay = '''.modal-overlay {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(4px);
    z-index: 1000;
    display: none;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}
.modal-overlay.active {
    display: flex;
    opacity: 1;
}'''

    new_modal_overlay = '''.modal-overlay {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(4px);
    z-index: 1000;
    display: none;
    overflow-y: auto;
    padding: 40px 20px;
    opacity: 0;
    transition: opacity 0.3s ease;
}
.modal-overlay.active {
    display: block;
    opacity: 1;
}'''

    old_modal_content = '''.modal-content {
    background: white;
    width: 90%;
    max-width: 600px;
    border-radius: 12px;
    padding: 30px;
    position: relative;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    transform: translateY(20px);
    transition: transform 0.3s ease;
    max-height: 90vh;
    overflow-y: auto;
}'''

    new_modal_content = '''.modal-content {
    background: white;
    width: 100%;
    max-width: 600px;
    margin: 0 auto;
    border-radius: 12px;
    padding: 30px;
    position: relative;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    transform: translateY(20px);
    transition: transform 0.3s ease;
}'''

    css = css.replace(old_modal_overlay, new_modal_overlay)
    css = css.replace(old_modal_content, new_modal_content)

    with io.open(style_css, 'w', encoding='utf-8') as f:
        f.write(css)
    print("Updated style.css")
except Exception as e:
    print("Error CSS:", e)

# 2. Update index.html for click outside to close
try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    old_div = '<div id="contactModal" class="modal-overlay">'
    new_div = '<div id="contactModal" class="modal-overlay" onclick="if(event.target===this) closeContactModal()">'
    
    html = html.replace(old_div, new_div)

    with io.open(index_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated index.html")
except Exception as e:
    print("Error HTML:", e)
