import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The text to replace
    old_text = 'Thiết kế & Chuyển đổi mô hình vận hành nhà máy'
    new_text = 'Thiết kế & Chuyển đổi<br>Mô hình vận hành nhà máy.'
    
    if old_text in html:
        # Note: the hero title also has "Thiết kế & Chuyển đổi Mô hình vận hành nhà máy" but with capital "Mô",
        # wait, let's be specific to the footer element to avoid replacing the hero title accidentally if it matches.
        
        # In the footer, the HTML looks like:
        # <p class="text-muted mb-4">Thiết kế & Chuyển đổi mô hình vận hành nhà máy</p>
        
        old_p = '<p class="text-muted mb-4">Thiết kế & Chuyển đổi mô hình vận hành nhà máy</p>'
        new_p = '<p class="text-muted mb-4">Thiết kế & Chuyển đổi<br>Mô hình vận hành nhà máy.</p>'
        
        if old_p in html:
            html = html.replace(old_p, new_p)
        else:
            # Fallback if there are spaces or something
            html = html.replace(old_text, new_text)
            
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old text in index.html")
except Exception as e:
    print("Error HTML:", e)
