import io
import re
import os

root_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

# Match <div class="card-icon"...>
pattern_icon = r'<div class="card-icon"([^>]*)>\s*<i data-lucide="([^"]+)"></i>\s*</div>\s*<h3([^>]*)>(.*?)</h3>'

def replacer_icon(match):
    icon_attrs = match.group(1)
    icon_name = match.group(2)
    h3_attrs = match.group(3)
    title = match.group(4)
    
    if 'style="' in h3_attrs:
        h3_attrs = h3_attrs.replace('style="', 'style="margin-bottom: 0; margin-top: 4px; line-height: 1.4; ')
    else:
        h3_attrs += ' style="margin-bottom: 0; margin-top: 4px; line-height: 1.4;"'
        
    if 'style="' in icon_attrs:
        icon_attrs = icon_attrs.replace('style="', 'style="margin-bottom: 0; flex-shrink: 0; ')
    else:
        icon_attrs += ' style="margin-bottom: 0; flex-shrink: 0;"'
        
    return f"""<div style="display: flex; align-items: flex-start; gap: 16px; margin-bottom: 16px;">
                        <div class="card-icon"{icon_attrs}>
                            <i data-lucide="{icon_name}"></i>
                        </div>
                        <h3{h3_attrs}>{title}</h3>
                    </div>"""

count = 0
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            new_html = re.sub(pattern_icon, replacer_icon, html)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Fixed remaining card titles globally in {count} html files.")
