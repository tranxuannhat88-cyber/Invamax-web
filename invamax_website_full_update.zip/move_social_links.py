import io
import re
import os

root_dir = r'C:\Users\MAY TINH 2K\Desktop\invamax-website'

# SVGs for Facebook and LinkedIn to be 100% safe
linkedin_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>'
facebook_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>'

social_block = f'''
                    <div class="social-links" style="margin-top: 24px; display: flex; gap: 16px;">
                        <a href="https://www.linkedin.com/in/xuannhattran/" target="_blank" style="color: var(--text-muted); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.05); transition: all 0.3s;" onmouseover="this.style.background='var(--primary)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.05)'; this.style.color='var(--text-muted)';">
                            {linkedin_svg}
                        </a>
                        <a href="https://www.facebook.com/invamax.vanhanhtinhgon" target="_blank" style="color: var(--text-muted); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.05); transition: all 0.3s;" onmouseover="this.style.background='var(--primary)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.05)'; this.style.color='var(--text-muted)';">
                            {facebook_svg}
                        </a>
                    </div>'''

count = 0
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with io.open(file_path, 'r', encoding='utf-8') as f:
                html = f.read()
            
            # Step 1: Remove old social links block
            # Note: The old block ends with </div>\n                </div> (the footer col close)
            # We'll just search for the entire <div class="social-links" ...> ... </div> block and remove it
            old_social_block_pattern = r'<div class="social-links" style="margin-top: 24px; display: flex; gap: 16px;">.*?</a>\s*</div>'
            html = re.sub(old_social_block_pattern, '', html, flags=re.DOTALL)
            
            # Step 2: Insert into "Về chúng tôi" column
            # Find the closing </div> of <div class="footer-links"> under <h4>Về chúng tôi</h4>
            # It looks like:
            # <h4>Về chúng tôi</h4>
            # <div class="footer-links">
            #     <a href="index.html">Giới thiệu</a>
            #     ...
            # </div>
            # </div> <-- We want to insert before this closing div, which means right after the footer-links closing div
            
            target_pattern = r'(<h4>Về chúng tôi</h4>\s*<div class="footer-links">.*?</div>)'
            # Insert the social_block after the matched group 1
            replacement = r'\1' + social_block
            
            new_html = re.sub(target_pattern, replacement, html, flags=re.DOTALL)
            
            if new_html != html:
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_html)
                count += 1

print(f"Moved social links and fixed icons in {count} html files.")
