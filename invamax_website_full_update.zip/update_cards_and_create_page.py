import io
import os
import re

dich_vu_html = "dich-vu.html"
source_file = "kham-benh-online/gioi-thieu.html"
target_dir = "kham-benh-truc-tiep"
target_file = os.path.join(target_dir, "gioi-thieu.html")

if not os.path.exists(target_dir):
    os.makedirs(target_dir)

try:
    with io.open(source_file, 'r', encoding='utf-8') as f:
        html = f.read()
        
    # Replace content
    html = html.replace('Giới thiệu Chương trình Khám bệnh Online - INVAMAX', 'Giới thiệu Chương trình Khám bệnh trực tiếp - INVAMAX')
    html = html.replace('Khám Bệnh Nhà Máy Online', 'Khám Bệnh Trực Tiếp Tại Nhà Máy')
    
    old_hero_p = 'Giải pháp chẩn đoán nhanh chóng, giúp Ban Giám Đốc và Quản lý xưởng nhìn rõ "điểm nghẽn", đánh giá mức độ lãng phí và định hướng cải tiến hệ thống vận hành chỉ trong 5 phút.'
    new_hero_p = 'Chuyên gia INVAMAX trực tiếp xuống hiện trường khảo sát toàn diện, phỏng vấn đội ngũ và lập báo cáo lộ trình cải tiến chi tiết, giải quyết các "điểm nghẽn" thực tế.'
    html = html.replace(old_hero_p, new_hero_p)
    
    # Update Card 1
    old_card1_ul = '''<ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li>Đánh giá khách quan sức khỏe hệ thống vận hành hiện tại.</li>
                            <li>Nhận diện nhanh các lãng phí tàng hình gây thất thoát chi phí.</li>
                            <li>Phát hiện các "căn bệnh" trong quản lý chất lượng, tiến độ và con người.</li>
                        </ul>'''
    new_card1_ul = '''<ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li>Khảo sát thực tế luồng công việc, layout và con người tại hiện trường.</li>
                            <li>Đánh giá sâu các điểm nghẽn mà dữ liệu online chưa thể hiện hết.</li>
                            <li>Lắng nghe trực tiếp từ đội ngũ quản lý và công nhân tại xưởng.</li>
                        </ul>'''
    html = html.replace(old_card1_ul, new_card1_ul)
    
    # Update Card 2
    old_card2_p = 'Chỉ với 5 phút thực hiện trắc nghiệm online:'
    new_card2_p = 'Chương trình làm việc tập trung tại nhà máy:'
    html = html.replace(old_card2_p, new_card2_p)
    
    old_card2_ul = '''<ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li>Trả lời các câu hỏi đánh giá thực trạng dựa trên thực tế xưởng.</li>
                            <li>Hệ thống AI sẽ tự động chấm điểm và chẩn đoán mức độ rủi ro.</li>
                            <li>Nhận ngay <strong>Báo cáo sơ bộ miễn phí</strong> trực tiếp trên web.</li>
                        </ul>'''
    new_card2_ul = '''<ul style="list-style-position: inside; color: var(--text-muted); line-height: 1.8;">
                            <li>Chuyên gia INVAMAX làm việc tại nhà máy trong tối đa 3 ngày.</li>
                            <li>Phỏng vấn, quan sát, đo lường và thu thập dữ liệu thực tế.</li>
                            <li>Trình bày báo cáo kết quả trực tiếp cho Ban Giám đốc và đề xuất lộ trình.</li>
                        </ul>'''
    html = html.replace(old_card2_ul, new_card2_ul)
    
    # Update Card 3
    old_card3_p = 'Hệ thống trả về Báo cáo chẩn đoán với giao diện trực quan, chấm điểm hệ thống từ 0-100 (5 cấp độ cảnh báo) và gợi ý hướng xử lý.'
    new_card3_p = 'Báo cáo chi tiết về tình trạng vận hành thực tế, phân tích nguyên nhân gốc rễ (root causes) và kế hoạch hành động cụ thể kèm theo lộ trình chuyển đổi tối ưu.'
    html = html.replace(old_card3_p, new_card3_p)
    
    # Update Bottom CTA
    old_cta_btn = '''<a href="index.html" class="btn btn-primary" style="font-size: 1.2rem; padding: 16px 40px; box-shadow: 0 4px 20px rgba(249, 115, 22, 0.4);">
                    <i data-lucide="play-circle"></i> Khám bệnh ngay
                </a>'''
    new_cta_btn = '''<button onclick="openContactModal()" class="btn btn-primary" style="font-size: 1.2rem; padding: 16px 40px; box-shadow: 0 4px 20px rgba(249, 115, 22, 0.4);">
                    <i data-lucide="phone-call"></i> Liên hệ để được tư vấn
                </button>'''
    html = html.replace(old_cta_btn, new_cta_btn)
    
    with io.open('index.html', 'r', encoding='utf-8') as idx_f:
        idx_html = idx_f.read()
    
    # Extract modal block from index.html
    modal_start = idx_html.find('<!-- Contact Modal -->')
    modal_html = ""
    if modal_start != -1:
        body_end = idx_html.find('</body>')
        if body_end != -1:
            modal_html = idx_html[modal_start:body_end].strip() + "\n\n"
        else:
            modal_html = idx_html[modal_start:].strip() + "\n\n"
            
    # Inject modal and scripts into new html
    if 'id="contactModal"' not in html and modal_html:
        body_end_pos = html.find('</body>')
        if body_end_pos != -1:
            scripts = '<script src="../assets/js/main.js"></script>\n'
            html = html[:body_end_pos] + modal_html + scripts + html[body_end_pos:]

    with io.open(target_file, 'w', encoding='utf-8') as f:
        f.write(html)
        
    print(f"Created {target_file}")
except Exception as e:
    print("Error creating kham-benh-truc-tiep:", e)
