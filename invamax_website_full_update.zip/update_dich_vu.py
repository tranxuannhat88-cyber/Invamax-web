import io
import os
import glob

# 1. Update navigation bar in all HTML files
html_files = glob.glob("*.html")
html_files.extend(glob.glob("kham-benh-online/*.html"))
html_files.extend(glob.glob("*/index.html"))

old_nav = 'Gói khám bệnh<br>nhà máy'
new_nav = 'Khám bệnh<br>nhà máy'

for file_path in set(html_files):
    if os.path.isfile(file_path):
        try:
            with io.open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if old_nav in content:
                content = content.replace(old_nav, new_nav)
                with io.open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Updated nav in {file_path}")
        except Exception as e:
            print(f"Error processing {file_path}: {e}")


# 2. Update dich-vu.html specific content
dich_vu_html = "dich-vu.html"
try:
    with io.open(dich_vu_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # Update description of 'Khám bệnh online'
    old_desc = 'Trao đổi trực tuyến 1-1 với chuyên gia, chẩn đoán nhanh các vấn đề nổi cộm dựa trên dữ liệu bạn cung cấp.'
    new_desc = 'Doanh nghiệp tự đánh giá tình trạng nhà máy thông qua bộ câu hỏi chuẩn hóa của INVAMAX để nhận diện nhanh các lỗ hổng quản trị và lãng phí.'
    if old_desc in html:
        html = html.replace(old_desc, new_desc)
        print("Updated Khám bệnh online description")
        
    # Remove the 'Giải quyết vấn đề / Cải tiến' card
    import re
    # The card starts with <div class="card" style="border-top: 4px solid var(--primary);"> and has 'Giải quyết vấn đề / Cải tiến' inside
    # We can match the entire card div
    card_pattern = r'<div class="card" style="border-top: 4px solid var\(--primary\);">(?:(?!<div class="card").)*?Giải quyết vấn đề \/ Cải tiến(?:(?!<div class="card").)*?<\/div>'
    match = re.search(card_pattern, html, re.DOTALL)
    if match:
        html = html.replace(match.group(0), "")
        print("Removed Giải quyết vấn đề card")
        
    with io.open(dich_vu_html, 'w', encoding='utf-8') as f:
        f.write(html)
    print("Updated dich-vu.html")

except Exception as e:
    print(f"Error processing dich-vu.html: {e}")
