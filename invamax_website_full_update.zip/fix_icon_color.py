import io
import re

css_path = r"assets\css\style.css"

with io.open(css_path, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Update .card-icon default colors
old_icon = """.card-icon {
    width: 64px;
    height: 64px;
    background-color: rgba(255, 107, 0, 0.1);
    color: var(--primary);"""
new_icon = """.card-icon {
    width: 64px;
    height: 64px;
    background-color: rgba(255, 255, 255, 0.05); /* neutral background */
    color: #a0aec0; /* neutral icon color */"""

if old_icon in css_content:
    css_content = css_content.replace(old_icon, new_icon)
else:
    print("Could not find old_icon exactly, trying regex")
    css_content = re.sub(
        r'\.card-icon\s*\{[\s\S]*?background-color:\s*rgba\(255,\s*107,\s*0,\s*0\.1\);[\s\S]*?color:\s*var\(--primary\);',
        r'.card-icon {\n    width: 64px;\n    height: 64px;\n    background-color: rgba(255, 255, 255, 0.05);\n    color: #a0aec0;',
        css_content
    )

# Also ensure hover makes the background orange tinted
hover_addon = """
.card:hover .card-icon, .intro-card:hover .card-icon {
    color: var(--primary);
    background-color: rgba(255, 107, 0, 0.1);
}
"""
if "background-color: rgba(255, 107, 0, 0.1);" not in css_content.split(".card:hover .card-icon")[-1]:
    css_content = css_content.replace(
        ".card:hover .card-icon, .intro-card:hover .card-icon {\n    color: var(--primary);\n}",
        ".card:hover .card-icon, .intro-card:hover .card-icon {\n    color: var(--primary);\n    background-color: rgba(255, 107, 0, 0.1);\n}"
    )

with io.open(css_path, 'w', encoding='utf-8') as f:
    f.write(css_content)
print("Updated style.css for card-icon")
