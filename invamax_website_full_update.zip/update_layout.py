import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    # The inline style to replace
    old_div = '<div style="display: flex; flex-direction: column; gap: 20px;">'
    new_div = '<div class="grid-2">'
    
    if old_div in html:
        html = html.replace(old_div, new_div)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old div structure in index.html")
except Exception as e:
    print("Error HTML:", e)
