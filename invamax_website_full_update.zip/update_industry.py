import io

index_html = r"index.html"

try:
    with io.open(index_html, 'r', encoding='utf-8') as f:
        html = f.read()

    old_input = '<input type="text" name="linhVuc" placeholder="Cơ khí, điện tử, may mặc...">'
    
    new_select = '''<select name="linhVuc">
                            <option value="">-- Chọn lĩnh vực --</option>
                            <option value="Gỗ / nội thất">Gỗ / nội thất</option>
                            <option value="Cơ khí / kim loại">Cơ khí / kim loại</option>
                            <option value="May mặc / da giày">May mặc / da giày</option>
                            <option value="Nhựa / cao su">Nhựa / cao su</option>
                            <option value="Thực phẩm / đồ uống">Thực phẩm / đồ uống</option>
                            <option value="Điện tử / điện lạnh">Điện tử / điện lạnh</option>
                            <option value="Vật liệu xây dựng">Vật liệu xây dựng</option>
                            <option value="Bao bì / in ấn">Bao bì / in ấn</option>
                            <option value="Khác">Khác</option>
                        </select>'''

    if old_input in html:
        html = html.replace(old_input, new_select)
        with io.open(index_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print("Updated index.html")
    else:
        print("Could not find the old input string in index.html")
except Exception as e:
    print("Error HTML:", e)
